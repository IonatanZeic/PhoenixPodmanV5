package com.clarifi.phoenix.ashes.task;

import com.clarifi.common.util.Logging;
import com.clarifi.phoenix.ashes.common.IssueDataSlicedByDataItem;
import com.clarifi.phoenix.ashes.common.PhoenixDate;
import com.clarifi.phoenix.ashes.common.PhoenixDateRange;
import com.clarifi.phoenix.ashes.common.TimeSeriesDataCache;
import com.clarifi.phoenix.ashes.data.DataItemSlicesIndex;
import com.clarifi.phoenix.ashes.data.TimeSeriesDataKey;
import org.apache.ignite.Ignite;
import org.apache.ignite.lang.IgniteCallable;
import org.apache.ignite.resources.IgniteInstanceResource;
import org.apache.logging.log4j.Logger;

import javax.cache.Cache;

public class GetTimeSeriesValue implements IgniteCallable<Double> {
    private static final Logger LOGGER = Logging.getLogger(GetTimeSeriesValue.class);

    private final int issueId;
    private final int dataItemId;
    private final PhoenixDate date;

    @IgniteInstanceResource
    private Ignite ignite;

    public GetTimeSeriesValue(final int issueId, final int dataItemId, final PhoenixDate date) {
        this.issueId = issueId;
        this.dataItemId = dataItemId;
        this.date = date;
    }

    @Override
    public Double call() {
        final TimeSeriesDataKey key = TimeSeriesDataCache.createKey(issueId, dataItemId);

        final Cache<TimeSeriesDataKey, DataItemSlicesIndex> cache = ignite.cache(TimeSeriesDataCache.getName());
        final DataItemSlicesIndex items = cache.get(key);
        if (items == null || items.isEmpty()) {
            return null;
        }

        // todo: this can be optimized by using a binary search or a scatter/gather approach
        for (final IssueDataSlicedByDataItem item : items.getAll()) {
            final PhoenixDateRange range = PhoenixDateRange.fromPackedValue(item.getDateRange());

            if (range.contains(date)) {
                char start = range.getStart().getPackedValue();
                int index = date.getPackedValue() - start;

                final double[] data = item.getValues();

                LOGGER.info(
                    "{Thread:{}} Value for issue={}, dataItem={} and date={} is {}",
                    Thread.currentThread().getName(),
                    key.issueId,
                    key.dataItemId,
                    date,
                    data[index]
                );

                return Double.valueOf(data[index]);
            }
        }

        return null;
    }
}
