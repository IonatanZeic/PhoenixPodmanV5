package com.clarifi.phoenix.ashes.server;

import com.amazon.ion.IonStruct;
import com.amazon.ion.IonSystem;
import com.amazon.ion.IonValue;
import com.amazon.ion.IonWriter;
import com.amazon.ion.system.IonSystemBuilder;
import com.amazon.ion.system.IonTextWriterBuilder;
import com.clarifi.phoenix.ashes.common.*;
import com.clarifi.phoenix.ashes.data.DataItemSlicesIndex;
import com.clarifi.phoenix.ashes.data.TimeSeriesDataKey;
import com.clarifi.phoenix.ashes.task.GetTimeSeries;
import com.clarifi.phoenix.ashes.task.GetTimeSeriesValue;
import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;
import io.undertow.util.Headers;
import io.undertow.util.PathTemplateMatch;
import io.undertow.util.StatusCodes;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCompute;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class GetTimeSeriesHandler implements HttpHandler {
    private final ServerApp server;

    public GetTimeSeriesHandler(final ServerApp server) {
        this.server = server;
    }

    @Override
    public void handleRequest(final HttpServerExchange exchange) {
        final PathTemplateMatch pathMatch = exchange.getAttachment(PathTemplateMatch.ATTACHMENT_KEY);
        final String issueId = pathMatch.getParameters().get("issueId");
        final String dataItemId = pathMatch.getParameters().get("dataItemId");

        final Ignite ignite = server.getIgnite();
        final IgniteCompute compute = ignite.compute();

        final TimeSeriesDataKey key = TimeSeriesDataCache.createKey(
            Integer.parseInt(issueId),
            Integer.parseInt(dataItemId)
        );

        final String date = pathMatch.getParameters().get("date");
        if (date != null && !date.isEmpty() && !date.isBlank()) {
            final LocalDate localDate = LocalDate.parse(date);
            final PhoenixDate phDate = PhoenixDate.fromLocalDate(localDate);

            final Double result = compute.affinityCall(
                    TimeSeriesDataCache.getName(),
                    key,
                    new GetTimeSeriesValue(Integer.parseInt(issueId), Integer.parseInt(dataItemId), phDate)
            );

            if (result != null) {
                exchange.setStatusCode(StatusCodes.OK);
                exchange.getResponseSender().send(String.format("Result: %.8f", result));
            } else {
                exchange.setStatusCode(StatusCodes.NOT_FOUND);
            }
        } else {
            // todo: this approach fails with OOM exception for large datasets; we need to
            // todo: refactor this to use a streaming approach and generate the response in chunks
            final DataItemSlicesIndex slices = compute.affinityCall(
                    TimeSeriesDataCache.getName(),
                    key,
                    new GetTimeSeries(Integer.parseInt(issueId), Integer.parseInt(dataItemId))
            );

            if (slices != null) {
                exchange.setStatusCode(StatusCodes.OK);

                final ByteArrayOutputStream stream = new ByteArrayOutputStream();
                final IonSystem ion = IonSystemBuilder.standard().build();
                //final IonWriter writer = ion.newTextWriter(stream);
                final IonWriter writer = IonTextWriterBuilder.json().build(stream);

                final List<IonStruct> results = new ArrayList<>();
                for (final IssueDataSlicedByDataItem cursor : slices.getAll()) {
                    final IonStruct struct = ion.newEmptyStruct();
                    struct.add("issueId", ion.newInt(cursor.getIssueId()));
                    struct.add("dataItemId", ion.newInt(cursor.getDataItemId()));

                    final PhoenixDateRange range = PhoenixDateRange.fromPackedValue(cursor.getDateRange());
                    struct.add("range", PhoenixDateRange.toIon(range, ion));

                    final List<IonValue> points = new LinkedList<>();
                    for (final Double item : cursor.getValues()) {
                        points.add(ion.newDecimal(item.doubleValue()));
                    }

                    struct.add("values", ion.newList(points));

                    results.add(struct);
                }

                ion.newList(results).writeTo(writer);

                final byte[] payload = stream.toByteArray();

                exchange.getResponseHeaders().put(Headers.CONTENT_LENGTH, Integer.toString(payload.length));
                exchange.getResponseHeaders().put(Headers.CONTENT_TYPE, PhoenixMimeTypes.TEXT_JSON);

                exchange.getResponseSender().send(ByteBuffer.wrap(payload));
            } else {
                exchange.setStatusCode(StatusCodes.NOT_FOUND);
            }
        }

        exchange.endExchange();
    }
}
