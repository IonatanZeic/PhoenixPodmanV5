package com.clarifi.phoenix.ashes.common;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class IssueDataSlicedByDataItem {
    private final int issueId;
    private final int dataItemId;
    private final int dateRange;

    private double[] values;

    public IssueDataSlicedByDataItem(final int issueId, final int dataItemId, final int range) {
        this.issueId = issueId;
        this.dataItemId = dataItemId;
        this.dateRange = range;

        values = null;
    }

    public int getIssueId() {
        return issueId;
    }

    public int getDataItemId() {
        return dataItemId;
    }

    public int getDateRange() {
        return dateRange;
    }

    public double[] getValues() {
        return values;
    }

    @Override
    public int hashCode() {
        return Objects.hash(issueId, dataItemId, dateRange, Arrays.hashCode(values));
    }

    @Override
    public boolean equals(final Object obj) {
        if (obj instanceof IssueDataSlicedByDataItem) {
            final IssueDataSlicedByDataItem candidate = (IssueDataSlicedByDataItem) obj;

            if (issueId != candidate.getIssueId()) {
                return false;
            }

            if (dataItemId != candidate.getDataItemId()) {
                return false;
            }

            if (dateRange != candidate.getDateRange()) {
                return false;
            }

            return Arrays.compare(values, candidate.getValues()) == 0;
        }

        return false;
    }

    public boolean contains(final IssueDataSlicedByDataItem inner) {
        if (issueId != inner.getIssueId()) {
            return false;
        }

        if (dataItemId != inner.getDataItemId()) {
            return false;
        }

        final PhoenixDateRange range = PhoenixDateRange.fromPackedValue(dateRange);
        return range.includes(PhoenixDateRange.fromPackedValue(inner.getDateRange()));
    }

    public static class Builder {
        private int issueId, dataItemId;
        private PhoenixDateRange range;
        private final Map<Character, Double> values;

        public Builder() {
            issueId = dataItemId = -1;
            range = PhoenixDateRange.empty();

            values = new HashMap<>();
        }

        public void setIssueId(final int value) {
            this.issueId = value;
        }

        public void setDataItemId(final int value) {
            this.dataItemId = value;
        }

        public void setRange(final PhoenixDateRange value) {
            this.range = value;
        }

        public void setValue(final PhoenixDate date, final double value) {
            final Character key = Character.valueOf(date.getPackedValue());
            values.put(key, Double.valueOf(value));
        }

        public IssueDataSlicedByDataItem build() {
            final IssueDataSlicedByDataItem slice = new IssueDataSlicedByDataItem(
                    issueId, dataItemId, range.getPackedValue());

            final int days = range.getNumberOfDays();
            slice.values = new double[days];

            int idx = 0;

            PhoenixDate cursor = range.getStart();
            while (range.contains(cursor)) {
                final Character key = Character.valueOf(cursor.getPackedValue());
                final Double value = values.get(key);

                slice.values[idx++] = value == null ? Double.NaN : value.doubleValue();

                cursor = cursor.plusDays(1);
            }

            return slice;
        }
    }
}
