package com.clarifi.phoenix.ashes.node;

import com.clarifi.phoenix.ashes.common.Common;
import com.clarifi.phoenix.ashes.data.TimeSeriesData;
import com.clarifi.phoenix.ashes.data.TimeSeriesDataCache;
import com.clarifi.phoenix.ashes.data.TimeSeriesDataKey;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteException;
import org.apache.ignite.Ignition;
import org.apache.ignite.configuration.IgniteConfiguration;

/**
 * A class to calculate a sum of a range of data items
 */
public class SumDataItems {

  public static void main(String[] args) throws IgniteException
  {
    IgniteConfiguration cfg = Common.igniteClientConfiguration();

    // Starting the node
    Ignite ignite = Ignition.start(cfg);
    try {

      IgniteCache<TimeSeriesDataKey, TimeSeriesData> tsCache = ignite.cache(Common.TIMESERIES_DATA_CACHE);

      if (tsCache == null) {
        System.out.println("Time series data cache " + Common.TIMESERIES_DATA_CACHE + " is not found, exiting");
        return;
      }

      int resultItemId = TimeSeriesDataCache.generateDerivedDataItemId(1);
      int[] issueRange = new int[] {1, 1000};
      int[] dataItemRange =  new int[] {1, 50};

      System.out.println("Computing sum for issueIds = [" + issueRange[0] + ", " + issueRange[1] +
        "]    dataItems = [" + dataItemRange[0] + ", " + dataItemRange[1] + "]");
      long startTime = System.currentTimeMillis();
      sumDataItems(tsCache, resultItemId, issueRange, dataItemRange);
      long stopTime = System.currentTimeMillis();

      long execTimeMs = (stopTime - startTime);
      System.out.println("Computation time = " + execTimeMs + " ms");

    }
    finally {
      // Disconnect from the cluster.
      ignite.close();
    }
  }

  private static void sumDataItems(IgniteCache<TimeSeriesDataKey, TimeSeriesData> tsCache, int resultItemId,
                                   int[] issueRange, int[] itemRange)
  {
    for (int i = issueRange[0]; i <= issueRange[1]; ++i) {
      int issueId = TimeSeriesDataCache.generateIssueId(i);
      TimeSeriesData sum = sumDataItems(tsCache, issueId, itemRange);

      TimeSeriesDataKey key = new TimeSeriesDataKey(issueId, resultItemId);

      tsCache.put(key, sum);
    }
  }

  private static TimeSeriesData sumDataItems(IgniteCache<TimeSeriesDataKey, TimeSeriesData> tsCache, int issueId, int[] itemRange) {
    int startItem = itemRange[0];
    int stopItem = itemRange[1];

    TimeSeriesData result = null;
    System.out.println("\tProcessing issueId = " + issueId);

    for (int i = startItem; i <=stopItem; ++i) {
      int dataItemId = TimeSeriesDataCache.generateDataItemId(i);
      TimeSeriesDataKey key = new TimeSeriesDataKey(issueId, dataItemId);
      TimeSeriesData ts = tsCache.get(key);

      if (ts == null)
        throw new IllegalStateException("Missing time series data for issueId = " + issueId + ", dataItemId = " + dataItemId);
      if (result == null) {
        result = new TimeSeriesData(ts);
      }
      else {
        add(result, ts);
      }
    }

    return result;
  }

  private static void add(TimeSeriesData result, TimeSeriesData ts) {
    for (int i = 0; i < result.values.length; ++i) {
      result.values[i] += ts.values[i];
    }
  }


}
