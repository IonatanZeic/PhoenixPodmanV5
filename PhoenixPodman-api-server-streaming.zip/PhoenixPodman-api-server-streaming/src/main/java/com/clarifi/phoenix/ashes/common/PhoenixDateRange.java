package com.clarifi.phoenix.ashes.common;

import com.amazon.ion.IonReader;
import com.amazon.ion.IonStruct;
import com.amazon.ion.IonSystem;
import com.amazon.ion.IonType;

import java.lang.ref.WeakReference;

public class PhoenixDateRange {
    private static final PhoenixDateRange EMPTY = new PhoenixDateRange(PhoenixDate.MIN, PhoenixDate.MIN);

    private final int packed;
    private WeakReference<PhoenixDate[]> unpacked;

    public PhoenixDateRange(final int value) {
        packed = value;
    }

    public PhoenixDateRange(final PhoenixDate start, final PhoenixDate end) {
        packed = (start.getPackedValue() << 16) | end.getPackedValue();
    }

    public PhoenixDate getStart() {
        final PhoenixDate[] range = unpack();
        return range[0];
    }

    public PhoenixDate getEnd() {
        final PhoenixDate[] range = unpack();
        return range[1];
    }

    @Override
    public boolean equals(final Object obj) {
        if (obj instanceof PhoenixDateRange) {
            final PhoenixDateRange candidate = (PhoenixDateRange) obj;
            return packed == candidate.getPackedValue();
        }

        return false;
    }

    @Override
    public String toString() {
        return String.format("%s to %s", getStart(), getEnd());
    }

    public PhoenixDateRange withStart(final int year, final int month, final int day) {
        return new PhoenixDateRange(PhoenixDate.of(year, month, day), getEnd());
    }

    public PhoenixDateRange withEnd(final int year, final int month, final int day) {
        return new PhoenixDateRange(getStart(), PhoenixDate.of(year, month, day));
    }

    public static PhoenixDateRange empty() {
        return EMPTY;
    }

    public int getPackedValue() {
        return packed;
    }

    public int getNumberOfDays() {
        final PhoenixDate[] range = unpack();
        final int end = range[1].getPackedValue();
        final int start = range[0].getPackedValue();

        if (end < start) {
            return 0;
        }

        if (start == end) {
            return 1;
        }

        return 1 + (end - start);
    }

    public boolean contains(final PhoenixDate date) {
        final PhoenixDate[] range = unpack();
        final char packed = date.getPackedValue();

        if (packed < range[0].getPackedValue()) {
            return false;
        }

        return packed <= range[1].getPackedValue();
    }

    public boolean includes(final PhoenixDateRange inner) {
        if (inner.getStart().isBeforeOrEqual(getStart())) {
            return false;
        }

        return !inner.getEnd().isAfterOrEqual(getEnd());
    }

    //-- There is no need to synchronize this if we go for speed vs memory efficiency;
    // it will re-compute and re-assign if called from multiple threads without side effects.
    private PhoenixDate[] unpack() {
        if (unpacked != null) {
            final PhoenixDate[] reference = unpacked.get();
            if (reference != null) {
                return reference;
            }
        }

        final PhoenixDate[] range = new PhoenixDate[] {
                PhoenixDate.fromPackedValue((char) ((packed >>> 16) & 0xFFFF)),
                PhoenixDate.fromPackedValue((char) (packed & 0x0000FFFF))
        };

        unpacked = new WeakReference<>(range);

        return range;
    }

    public static PhoenixDateRange fromPackedValue(final int value) {
        return new PhoenixDateRange(value);
    }

    public static PhoenixDateRange startsIn(final int year, final int month, final int day) {
        return new PhoenixDateRange(PhoenixDate.of(year, month, day), PhoenixDate.MAX);
    }

    public static PhoenixDateRange endsIs(final int year, final int month, final int day) {
        return new PhoenixDateRange(PhoenixDate.MIN, PhoenixDate.of(year, month, day));
    }

    public static IonStruct toIon(final PhoenixDateRange range, final IonSystem ion) {
        final PhoenixDate startDate = range.getStart();
        final PhoenixDate endDate = range.getEnd();

        final IonStruct end = ion.newEmptyStruct();
        end.add("year", ion.newInt(endDate.getYear()));
        end.add("month", ion.newInt(endDate.getMonth()));
        end.add("day", ion.newInt(endDate.getDayOfMonth()));

        final IonStruct start = ion.newEmptyStruct();
        start.add("year", ion.newInt(startDate.getYear()));
        start.add("month", ion.newInt(startDate.getMonth()));
        start.add("day", ion.newInt(startDate.getDayOfMonth()));

        final IonStruct result = ion.newEmptyStruct();
        result.add("start-date", start);
        result.add("end-date", end);

        return result;
    }

    public static PhoenixDateRange fromIon(final IonReader reader) {
        // todo: replace with Builder pattern
        PhoenixDate start = PhoenixDate.MIN, end = PhoenixDate.MIN;

        IonType cursor = reader.next();
        while (cursor != null) {
            String field = reader.getFieldName();
            switch (field) {
                case "start-date":
                    reader.stepIn();
                    start = parseIonDate(reader);
                    reader.stepOut();
                    break;

                case "end-date":
                    reader.stepIn();
                    end = parseIonDate(reader);
                    reader.stepOut();
                    break;
            }

            cursor = reader.next();
        }

        return new PhoenixDateRange(start, end);
    }

    private static PhoenixDate parseIonDate(final IonReader reader) {
        int year = 0, month = 0, day = 0;

        IonType cursor = reader.next();
        while (cursor != null) {
            String field = reader.getFieldName();
            switch (field) {
                case "year":
                    year = reader.intValue();
                    break;

                case "month":
                    month = reader.intValue();
                    break;

                case "day":
                    day = reader.intValue();
                    break;
            }

            cursor = reader.next();
        }

        return PhoenixDate.of(year, month, day);
    }
}
