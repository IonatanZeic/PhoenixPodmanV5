package com.clarifi.phoenix.ashes.util;

import com.clarifi.phoenix.ashes.common.Common;
import com.clarifi.phoenix.ashes.data.TimeSeriesData;
import com.clarifi.phoenix.ashes.data.TimeSeriesDataCache;
import com.clarifi.phoenix.ashes.data.TimeSeriesDataKey;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteException;
import org.apache.ignite.Ignition;
import org.apache.ignite.configuration.CacheConfiguration;
import org.apache.ignite.configuration.IgniteConfiguration;

/**
 * A class to load some sample data into Ignite caches
 */
public class LoadSampleTimeSeriesData {

  public static void main(String[] args) throws IgniteException
  {
    IgniteConfiguration cfg = Common.igniteClientConfiguration();
    CacheConfiguration cacheCfg = TimeSeriesDataCache.timeSeriesDataCacheConfiguration();

    // Starting the node
    Ignite ignite = Ignition.start(cfg);

    // Create an IgniteCache and put some values in it.
    IgniteCache<TimeSeriesDataKey, TimeSeriesData> tsCache = ignite.getOrCreateCache(cacheCfg);

    // Create an IgniteCache and put some values in it.
    int numDataItems = 100;
    int numIssues = 1000;
    int numDates = 100;
    try {
      loadTimeSeriesValues(tsCache, numDataItems, numIssues, numDates);
    }
    finally {
      // Disconnect from the cluster.
      ignite.close();
    }
  }

  private static void loadTimeSeriesValues( IgniteCache<TimeSeriesDataKey, TimeSeriesData> tsCache,
                                            int numDataItems, int numIssues, int numDates)
  {
    System.out.println(">>> Loading " + numDataItems + " data items for " + numIssues + " issues over " + numDates + "dates.");
    long sizeEstimateMB = numDataItems * numIssues * TimeSeriesData.sizeInBytes(numDataItems) / 1024 / 1024;
    System.out.println(">>> Data size estimated at " + sizeEstimateMB + " MB.");

    for (int i = 0; i < numIssues; ++i) {
      int issueId = TimeSeriesDataCache.generateIssueId(i);
      System.out.println(">>> Loading data for issue id = " + issueId);
      for (int di = 0; di < numDataItems; ++di) {
        int dataItemId = TimeSeriesDataCache.generateDataItemId(di);

        TimeSeriesData tsData = TimeSeriesData.fill(issueId, dataItemId, numDates);
        TimeSeriesDataKey key = new TimeSeriesDataKey(issueId, dataItemId);

        tsCache.put(key, tsData);
      }
    }

    System.out.println(">>> Finished loading time series values.");
  }

}
