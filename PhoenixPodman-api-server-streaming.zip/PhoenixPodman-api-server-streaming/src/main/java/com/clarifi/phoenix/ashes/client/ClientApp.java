package com.clarifi.phoenix.ashes.client;

import com.amazon.ion.*;
import com.amazon.ion.system.IonSystemBuilder;
import com.clarifi.common.application.App;
import com.clarifi.common.util.Logging;
import com.clarifi.phoenix.ashes.common.*;
import io.undertow.util.StatusCodes;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class ClientApp {
    private static final Logger LOGGER = Logging.getLogger(ClientApp.class);

    private final String host;
    private final int port;
    private final IonSystem ion;

    private HttpClient httpClient;

    public ClientApp(final String host, final int port) {
        this.host = host;
        this.port = port;

        httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(5L))
                .version(HttpClient.Version.HTTP_2)
                .followRedirects(HttpClient.Redirect.ALWAYS)
                .build();

        ion = IonSystemBuilder.standard().build();
    }

    private HttpRequest.Builder request(final String path, final Map<String, String> params) {
        final URLBuilder builder = new URLBuilder();
        builder.http().host(host).port(port).path("api2", path);
        builder.addQueryParameters(params);

        return HttpRequest.newBuilder()
                .version(HttpClient.Version.HTTP_2)
                .uri(builder.build())
                .timeout(Duration.ofSeconds(5L));
    }

    private DataSession parseDataSession(final InputStream stream) throws IOException {
        final PackedDataSession.Reader reader = new PackedDataSession.IonReader();

        return reader.read(stream.readAllBytes());
    }

    public PhoenixUser authenticate(final String userName, String password) {
        // todo: implement

        String token = AuthenticationService.getToken(userName,"Phoenix@1234");
        return new PhoenixUser(userName,token);
    }

    private void writeDataSession(final PhoenixUser user,
                                  final PhoenixDateRange range,
                                  final int[] dataItems,
                                  final int[] issues,
                                  final OutputStream stream) {
        final IonStruct params = ion.newEmptyStruct();
        params.add("user", ion.newString(user.getId().toString()));
        params.add("range", PhoenixDateRange.toIon(range, ion));
        params.add("dataItems", ion.newList(dataItems));
        params.add("issues", ion.newList(issues));
        params.add("lastAccessedAt", ion.newInt(Instant.now().toEpochMilli()));

        final IonWriter writer = ion.newTextWriter(stream);
        try {
            params.writeTo(writer);

            writer.flush();
            writer.close();

            stream.flush();
        } catch (final Throwable err) {
            LOGGER.error("Error building Ion data session: {}", err);
        }
    }

    public DataSession createDataSession(final PhoenixUser user, final PhoenixDateRange range,
                                         final int[] dataItems, final int[] issues) {
         try {
            final Map<String, String> params = new HashMap<>();
            params.put("timeout", Integer.toString(10));

            final HttpRequest.Builder builder = request("data-session/new", params);
            if (user.hasOktaToken()) {
                builder.header("Token", user.getOktaToken());
            }

            final ByteArrayOutputStream stream = new ByteArrayOutputStream();
            writeDataSession(user, range, dataItems, issues, stream);
            builder.PUT(HttpRequest.BodyPublishers.ofByteArray(stream.toByteArray()));

            builder.timeout(Duration.ofSeconds(20L));
            final HttpRequest request = builder.build();
            final HttpResponse<InputStream> response = httpClient.send(
                    request, HttpResponse.BodyHandlers.ofInputStream());

            // todo: handle other response codes
            if (response.statusCode() == StatusCodes.OK) {
                try (final InputStream data = response.body()) {
                    return parseDataSession(data);
                }
            }
        } catch (final Throwable err) {
             LOGGER.error("Error creating data session: {}", err);
        }

        return null;
    }

    public DataSession generateDataSession(final PhoenixUser user, final int dataItemsCount,
                                           final int issuesCount,
                                           final PhoenixDateRange range) {
        final int[] dataItems = new int[dataItemsCount];
        for (int idx = 0; idx < dataItems.length; idx++) {
            dataItems[idx] = 100 + idx;
        }

        final int[] issues = new int[issuesCount];
        for (int idx = 0; idx < issues.length; idx++) {
            issues[idx] = 1000 + idx;
        }

        try {
            final Map<String, String> params = new HashMap<>();
            params.put("timeout", Integer.toString(30));

            final HttpRequest.Builder builder = request("data-session/new", params);
            builder.header("Content-Encoding", "gzip");
            builder.header("Accept-Encoding", "gzip");

            if (user.hasOktaToken()) {
                builder.header("Phoenix-Auth-Token", user.getOktaToken());
            }

            final ByteArrayOutputStream stream = new ByteArrayOutputStream();
            writeDataSession(user, range, dataItems, issues, new GZIPOutputStream(stream));
            builder.POST(HttpRequest.BodyPublishers.ofByteArray(stream.toByteArray()));

            builder.timeout(Duration.ofSeconds(35L));
            final HttpRequest request = builder.build();

            final HttpResponse<InputStream> response = httpClient.send(
                    request, HttpResponse.BodyHandlers.ofInputStream());

            // todo: handle other response codes
            if (response.statusCode() == StatusCodes.OK) {
                final List<String> encodings = response.headers().allValues("Content-Encoding");
                if (encodings.contains("gzip")) {
                    return parseDataSession(new GZIPInputStream(response.body()));
                } else {
                    return parseDataSession(response.body());
                }
            } else if (response.statusCode() == StatusCodes.REQUEST_TIME_OUT) {
                UUID sessionId = null;

                try (final InputStream inStream = response.body()) {
                    final IonReader reader = ion.newReader(inStream);
                    reader.next();

                    reader.stepIn();
                    while (reader.next() != null) {
                        LOGGER.info("{}: {}", reader.getFieldName(), reader.getType());

                        if ("sessionId".equals(reader.getFieldName())) {
                            sessionId = UUID.fromString(reader.stringValue());
                        }
                    }
                    reader.stepOut();
                }

                LOGGER.info("Data loading for session '{}' timed out; will retry every 10 seconds...", sessionId);

                int remaining = 180;
                while (remaining > 0) {
                    TimeUnit.SECONDS.sleep(10L);

                    final DataSession session = getDataSession(sessionId, user);
                    if (session != null && DataSession.Status.Ready == session.getStatus()) {
                        return session;
                    }

                    remaining -= 10;
                }
            } else {
                LOGGER.error(
                        "Unknown response: Code: {}, Details: {}",
                        response.statusCode(),
                        new String(response.body().readAllBytes())
                );
            }
        } catch (final Throwable err) {
            LOGGER.error("Unexpected error: {}", err);
        }

        return null;
    }

    public DataSession getDataSession(final UUID id, final PhoenixUser user) {
        final HttpRequest request;
        try {
            final Map<String, String> params = new HashMap<>();
            params.put("userId", user.getId().toString());

            // todo: replace with path builder factory
            final String path = String.format("data-session/get/%s", id.toString());

            final HttpRequest.Builder builder = request(path, params);
            builder.header("Accept-Encoding", "gzip");

            if (user.hasOktaToken()) {
                builder.header("Phoenix-Auth-Token", user.getOktaToken());
            }

            builder.GET();

            request = builder.build();
        } catch (final Throwable err) {
            LOGGER.error("Error building request: {}", err);
            return null;
        }

        final HttpResponse<InputStream> response;
        try {
            response = httpClient.send(request, HttpResponse.BodyHandlers.ofInputStream());
        } catch (final Throwable err) {
            LOGGER.error("Error sending request: {}", err);
            return null;
        }

        // todo: handle other response codes
        if (response.statusCode() == StatusCodes.OK) {
            try (final InputStream stream = response.body()) {
                return parseDataSession(stream);
            } catch (final Throwable err) {
                LOGGER.error("Unsupported response code: {}", response.statusCode());
            }
        }

        return null;
    }

    public void readDataSessionContent(final UUID id, final PhoenixUser user) {
        final HttpRequest request;
        try {
            final Map<String, String> params = new HashMap<>();
            params.put("userId", user.getId().toString());

            // todo: replace with path builder factory
            final String path = String.format("data-session/time-series/%s", id.toString());

            final HttpRequest.Builder builder = request(path, params);
            builder.header("Accept-Encoding", "gzip");

            if (user.hasOktaToken()) {
                builder.header("Phoenix-Auth-Token", user.getOktaToken());
            }

            builder.timeout(Duration.ofSeconds(10L));
            builder.GET();

            request = builder.build();
        } catch (final Throwable err) {
            LOGGER.error("Error building request: {}", err);
            return;
        }

        final HttpResponse<InputStream> response;
        try {
            response = httpClient.send(request, HttpResponse.BodyHandlers.ofInputStream());
        } catch (final Throwable err) {
            LOGGER.error("Error sending request: {}", err);
            return;
        }

        if (response.statusCode() == StatusCodes.OK) {
            try (final InputStream inStream = response.body()) {
                final List<String> encodings = response.headers().allValues("Content-Encoding");

                final InputStream stream;
                if (encodings.contains("gzip")) {
                    stream = new GZIPInputStream(inStream);
                } else {
                    stream = inStream;
                }

                int slices = 0;
                final BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));

                boolean eof = false;
                while (!eof) {
                    final String line = reader.readLine();
                    if (line == null) {
                        eof = true;
                    } else {
                        System.out.println(line);
                        slices++;
                    }
                }

                LOGGER.info("Received {} lines from the server", slices);
            } catch (final Throwable err) {
                LOGGER.error("Error processing server response: {}", err);
            }
        } else if (response.statusCode() == StatusCodes.REQUEST_TIME_OUT) {
            LOGGER.warn("Request timed out");
        } else if (response.statusCode() == StatusCodes.NOT_FOUND) {
            String message = "N/A";
            try (final InputStream inStream = response.body()) {
                message = new String(inStream.readAllBytes());
            } catch (final IOException io) {
                LOGGER.error("Error reading response: {}", io);
            }

            LOGGER.warn("Not found: {}", message);
        } else {
            LOGGER.error("Unknown reply from server: {}", response.statusCode());
        }
    }

    public void dumpDataSessionContent(final UUID id, final PhoenixUser user) {
        final HttpRequest request;
        try {
            final Map<String, String> params = new HashMap<>();
            params.put("userId", user.getId().toString());

            // todo: replace with path builder factory
            final String path = String.format("data-session/time-series/%s", id.toString());

            final HttpRequest.Builder builder = request(path, params);
            builder.header("Accept-Encoding", "gzip");

            if (user.hasOktaToken()) {
                builder.header("Phoenix-Auth-Token", user.getOktaToken());
            }

            builder.timeout(Duration.ofSeconds(10L));
            builder.GET();

            request = builder.build();
        } catch (final Throwable err) {
            LOGGER.error("Error building request: {}", err);
            return;
        }

        final HttpResponse<InputStream> response;
        try {
            response = httpClient.send(request, HttpResponse.BodyHandlers.ofInputStream());
        } catch (final Throwable err) {
            LOGGER.error("Error sending request: {}", err);
            return;
        }

        if (response.statusCode() == StatusCodes.OK) {
            final IonReader reader;
            try (final InputStream inStream = response.body()) {
                final List<String> encodings = response.headers().allValues("Content-Encoding");
                if (encodings.contains("gzip")) {
                    reader = ion.newReader(new GZIPInputStream(inStream));
                } else {
                    reader = ion.newReader(inStream);
                }

                int slices = 0;
                int depth = 0;
                while (reader.next() != null) {
                    if (reader.getType() == IonType.STRUCT) {
                        reader.stepIn();

                        int issueId = -1, dataItemId = -1;
                        PhoenixDateRange range = PhoenixDateRange.empty();
                        final List<Double> values = new LinkedList<>();

                        while (reader.next() != null) {
                            switch (reader.getFieldName()) {
                                case "issueId":
                                    issueId = reader.intValue();
                                    break;

                                    case "dataItemId":
                                    dataItemId = reader.intValue();
                                    break;

                                case "range":
                                    reader.stepIn();
                                    range = PhoenixDateRange.fromIon(reader);
                                    reader.stepOut();
                                    break;

                                case "values":
                                    reader.stepIn();
                                    while (reader.next() != null) {
                                        values.add(Double.valueOf(reader.doubleValue()));
                                    }
                                    reader.stepOut();
                                    break;
                            }

                        }

                        reader.stepOut();

                        slices++;

                        System.out.printf("{issueId: %d, dataItemId: %d, range: %s, values: [", issueId, dataItemId, range);
                        for (final Double item: values) {
                            System.out.print(String.format("%.8f, ", item.doubleValue()));
                        }
                        System.out.println("]}");

                        TimeUnit.MILLISECONDS.sleep(150L);
                    } else if (reader.getType() == IonType.LIST) {
                        reader.stepIn();

                        depth += 1;
                    }
                }

                LOGGER.info("Received {} slices from the server", slices);
            } catch (final Throwable err) {
                LOGGER.error("Error processing server response: {}", err);
            }
        } else if (response.statusCode() == StatusCodes.REQUEST_TIME_OUT) {
            LOGGER.warn("Request timed out");
        } else if (response.statusCode() == StatusCodes.NOT_FOUND) {
            String message = "N/A";
            try (final InputStream inStream = response.body()) {
                message = new String(inStream.readAllBytes());
            } catch (final IOException io) {
                LOGGER.error("Error reading response: {}", io);
            }

            LOGGER.warn("Not found: {}", message);
        } else {
            LOGGER.error("Unknown reply from server: {}", response.statusCode());
        }
    }

    public void dumpDataSessionsIssueCount(final PhoenixUser user, final boolean useTL) {
        final HttpRequest request;
        try {
            final Map<String, String> params = new HashMap<>();
            params.put("useTL", useTL ? "yes" : "no");

            // todo: replace with path builder factory
            final String path = String.format("data-sessions/count-issues/%s", user.getId().toString());

            final HttpRequest.Builder builder = request(path, params);
            builder.timeout(Duration.ofSeconds(30L));

            if (user.hasOktaToken()) {
                builder.header("Phoenix-Auth-Token", user.getOktaToken());
            }

            builder.GET();

            request = builder.build();
        } catch (final Throwable err) {
            LOGGER.error("Error building request: {}", err);
            return;
        }

        final HttpResponse<InputStream> response;
        try {
            response = httpClient.send(request, HttpResponse.BodyHandlers.ofInputStream());
        } catch (final Throwable err) {
            LOGGER.error("Error sending request: {}", err);
            return;
        }

        // todo: handle other response codes
        if (response.statusCode() == StatusCodes.OK) {
            try (final InputStream stream = response.body()) {
                System.out.println(new String(stream.readAllBytes()));
            } catch (final IOException io) {
                LOGGER.error("Error reading response: {}", io);
            }
        }
    }

    public void dumpTimeSeries(final int issueId, final int dataItemId, final PhoenixDate date) {
        final HttpRequest request;
        try {
            // todo: replace with path builder factory
            final String path = String.format(
                    "time-series/%d/%d/%d-%02d-%02d",
                    issueId,
                    dataItemId,
                    date.getYear(),
                    date.getMonth(),
                    date.getDayOfMonth()
            );

            final HttpRequest.Builder builder = request(path, null);
            builder.timeout(Duration.ofSeconds(35L));

            builder.GET();

            request = builder.build();
        } catch (final Throwable err) {
            LOGGER.error("Error building request: {}", err);
            return;
        }

        final HttpResponse<InputStream> response;
        try {
            response = httpClient.send(request, HttpResponse.BodyHandlers.ofInputStream());
        } catch (final Throwable err) {
            LOGGER.error("Error sending request: {}", err);
            return;
        }

        // todo: handle other response codes
        if (response.statusCode() == StatusCodes.OK) {
            try (final InputStream stream = response.body()) {
                System.out.println(new String(stream.readAllBytes()));
            } catch (final IOException io) {
                LOGGER.error("Error reading response: {}", io);
            }
        } else {
            LOGGER.error("Unknown response from server: {}", response.statusCode());
        }
    }

    public void dumpTimeSeriesSlices(final int issueId, final int dataItemId,
                                     final PhoenixDate startDate, final PhoenixDate endDate) {
        final HttpRequest request;
        try {
            // todo: replace with path builder factory
            final String path = String.format(
                    "time-series/%d/%d/%d-%02d-%02d/%d-%02d-%02d",
                    issueId,
                    dataItemId,
                    startDate.getYear(),
                    startDate.getMonth(),
                    startDate.getDayOfMonth(),
                    endDate.getYear(),
                    endDate.getMonth(),
                    endDate.getDayOfMonth()
            );

            final HttpRequest.Builder builder = request(path, null);
            builder.timeout(Duration.ofSeconds(35L));

            builder.GET();

            request = builder.build();
        } catch (final Throwable err) {
            LOGGER.error("Error building request: {}", err);
            return;
        }

        final HttpResponse<InputStream> response;
        try {
            response = httpClient.send(request, HttpResponse.BodyHandlers.ofInputStream());
        } catch (final Throwable err) {
            LOGGER.error("Error sending request: {}", err);
            return;
        }

        // todo: handle other response codes
        if (response.statusCode() == StatusCodes.OK) {
            try (final InputStream stream = response.body()) {
                System.out.println(new String(stream.readAllBytes()));
            } catch (final IOException io) {
                LOGGER.error("Error reading response: {}", io);
            }
        } else {
            LOGGER.error("Unknown response from server {}", response.statusCode());
        }
    }

    public static void main(final String[] args) throws Throwable {
        App.initBeforeAnythingElse(args, 0, "Client App", "1.0.0");

        final ClientApp client = new ClientApp("localhost", 8081);

        App.appMain(new Runnable() {
            @Override
            public void run() {

            }
        }, new Runnable() {
            @Override
            public void run() {

            }
        });

        client.startup();
        client.shutdown();
    }

    private void startup() {
        final PhoenixUser user = this.authenticate("harsh.vardhan@spglobal.com","Phoenix@1234");
        LOGGER.info("User: {}", user);

//        final DataSession small = this.createDataSession(
//                user,
//                PhoenixDateRange.startsIn(2024, 1, 1).withEnd(2024, 12, 31),
//                new int[] { 101, 102 },
//                new int[] { 1001, 1002, 1003, 1004, 1005, 1006, 1007 }
//        );
//
//        System.out.println(small);
//
//        this.dumpDataSessionContent(small.getId(), user);
//
//        final DataSession copy = this.getDataSession(small.getId(), user);
//        // todo: deep compare session vs. copy
//        System.out.println(copy);

        final DataSession tiny = this.generateDataSession(
                user,
                2,
                4,
                PhoenixDateRange.startsIn(2023, 1, 1).withEnd(2023, 1, 3)
        );

        LOGGER.info("Tiny: {}", tiny);

        this.readDataSessionContent(tiny.getId(), user);

//        final DataSession large = this.generateDataSession(
//                user,
//                128,
//                24000,
//                PhoenixDateRange.startsIn(2023, 1, 1).withEnd(2023, 6, 30)
//        );
//
//        System.out.printf("Large: %s\n", large);

//        this.dumpTimeSeries(1001, 101, PhoenixDate.of(2024, 1, 11));
//        this.dumpTimeSeriesSlices(1002, 102, PhoenixDate.of(2024, 3, 1), PhoenixDate.of(2024, 3, 7));
//
//        this.dumpTimeSeries(1003, 103, PhoenixDate.of(2024, 1, 10));
//        this.dumpTimeSeries(1004, 104, PhoenixDate.of(2023, 6, 9));
//
//        this.dumpDataSessionsIssueCount(user, false);
//        this.dumpDataSessionsIssueCount(user, true);
    }

    private void shutdown() {
        try {
            httpClient.close();
        } catch (final Exception ex) {
            LOGGER.error("Error closing HTTP client: {}", ex.getMessage(), ex);
        } finally {
            httpClient = null;
        }
    }
}
