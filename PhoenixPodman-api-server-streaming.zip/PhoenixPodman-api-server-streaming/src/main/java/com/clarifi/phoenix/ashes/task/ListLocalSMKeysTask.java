package com.clarifi.phoenix.ashes.task;

import com.clarifi.phoenix.ashes.common.Common;
import com.clarifi.phoenix.ashes.common.IssueRangeAccumulator;
import com.clarifi.phoenix.ashes.data.IssueData;
import com.clarifi.phoenix.ashes.data.SecurityMasterCache;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.cache.CachePeekMode;
import org.apache.ignite.configuration.CacheConfiguration;
import org.apache.ignite.lang.IgniteRunnable;
import org.apache.ignite.resources.IgniteInstanceResource;

import javax.cache.Cache;
import java.util.*;

/**
 * A computation tasks that prints out a node ID and some details about its OS and JRE.
 * Plus, the code shows how to access data stored in a cache from the computation task.
 */
class ListLocalSMKeysTask implements IgniteRunnable {
  @IgniteInstanceResource
  Ignite ignite;

  @Override
  public void run() {
    System.out.println(">> Executing the List Local Security Master Keys Task");

    System.out.println("\tNode ID: " + ignite.cluster().localNode().id());

    IgniteCache<Integer, IssueData> cache = ignite.cache(Common.SECURITY_MASTER_CACHE);

    if (cache == null) {
      System.out.println("\tcache: " + Common.SECURITY_MASTER_CACHE + " does not exist.");
      return;
    }

    long numPrimaryEntries = cache.localSizeLong(CachePeekMode.PRIMARY);
    long numBackupEntries = cache.localSizeLong(CachePeekMode.BACKUP);

    CacheConfiguration<Integer, IssueData> cfg = cache.getConfiguration(SecurityMasterCache.configuration().getClass());
    System.out.println("\tCONFIG.getCacheMode = : " + cfg.getCacheMode());
    System.out.println("\tPRIMARY: " + numPrimaryEntries + " entries");
    System.out.println("\tBACKUP: " + numBackupEntries + " entries");

    System.out.println(">> List local keys for " + Common.SECURITY_MASTER_CACHE + " PRIMARY cache:");

    Iterable<Cache.Entry<Integer, IssueData>> es = cache.localEntries(CachePeekMode.PRIMARY);
    Iterator<Cache.Entry<Integer, IssueData>> it = es.iterator();
    List<Integer> issueIds = new ArrayList<>();
    while (it.hasNext()) {
      Cache.Entry<Integer, IssueData> kv = it.next();
      int issueId = kv.getKey();
      issueIds.add(issueId);
    }
    Collections.sort(issueIds);

    IssueRangeAccumulator consolidatedIssues = new IssueRangeAccumulator();
    for (int issueId : issueIds) {
      consolidatedIssues.add(issueId);
    }

    for (int[] range : consolidatedIssues.ranges) {
      System.out.println("\t\t[" + range[0] + " .. " + range[1] + "]");
    }
    int[] range = consolidatedIssues.currentRange;
    System.out.println("\t\t[" + range[0] + " .. " + range[1] + "]");
  }
}
