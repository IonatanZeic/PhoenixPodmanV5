package com.clarifi.phoenix.ashes.common;

import java.util.*;

public class IssueDataSlicedByDate {
    private final int issueId;
    private final char date;

    private int[] dataItems;
    private double[] values;

    public IssueDataSlicedByDate(final int issueId, final char date) {
        this.issueId = issueId;
        this.date = date;

        dataItems = null;
        values = null;
    }

    public int getIssueId() {
        return issueId;
    }

    public char getDate() {
        return date;
    }

    public int[] getDataItems() {
        return dataItems;
    }

    public double[] getValues() {
        return values;
    }

    @Override
    public int hashCode() {
        return Objects.hash(issueId, date, Arrays.hashCode(dataItems), Arrays.hashCode(values));
    }

    @Override
    public boolean equals(final Object obj) {
        if (obj instanceof IssueDataSlicedByDate) {
            final IssueDataSlicedByDate candidate = (IssueDataSlicedByDate) obj;

            if (issueId != candidate.getIssueId()) {
                return false;
            }

            if (date != candidate.getDate()) {
                return false;
            }

            if (Arrays.compare(dataItems, candidate.getDataItems()) != 0) {
                return false;
            }

            return Arrays.compare(values, candidate.getValues()) == 0;
        }

        return false;
    }

    public boolean contains(final IssueDataSlicedByDate inner) {
        if (issueId != inner.getIssueId()) {
            return false;
        }

        if (date != inner.getDate()) {
            return false;
        }

        if (inner.dataItems.length > dataItems.length) {
            return false;
        }

        for (int idx = 0; idx < inner.dataItems.length; idx++) {
            if (Arrays.binarySearch(dataItems, inner.dataItems[idx]) < 0) {
                return false;
            }
        }

        return true;
    }

    public static class Builder {
        private int issueId;
        private PhoenixDate date;
        private final List<Integer> items;
        private final Map<Integer, Double> values;

        public Builder() {
            issueId = -1;
            date = PhoenixDate.MIN;

            items = new ArrayList<>();
            values = new HashMap<>();
        }

        public void setIssueId(final int value) {
            this.issueId = value;
        }

        public void setDate(final PhoenixDate value) {
            this.date = value;
        }

        public int addDataItem(final int value) {
            final int index = items.size();
            items.add(Integer.valueOf(value));

            values.put(Integer.valueOf(index), Double.NaN);

            return index;
        }

        public void setValue(final int index, final double value) {
            final Integer key = Integer.valueOf(index);
            values.put(key, Double.valueOf(value));
        }

        public IssueDataSlicedByDate build() {
            final IssueDataSlicedByDate slice = new IssueDataSlicedByDate(issueId, date.getPackedValue());

            items.sort(new Comparator<Integer>() {
                @Override
                public int compare(final Integer o1, final Integer o2) {
                    return Integer.compare(o1, o2);
                }
            });

            slice.dataItems = new int[items.size()];
            slice.values = new double[items.size()];

            for (int idx = 0; idx < items.size(); idx++) {
                slice.dataItems[idx] = items.get(idx).intValue();
                slice.values[idx] = values.get(Integer.valueOf(idx));
            }

            return slice;
        }
    }
}
