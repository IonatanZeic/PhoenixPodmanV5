package com.clarifi.phoenix.ashes.server;

import com.amazon.ion.IonSystem;
import com.amazon.ion.system.IonSystemBuilder;
import com.clarifi.common.util.Logging;
import com.clarifi.concurrent.Unification;
import com.clarifi.concurrent.batch.task.*;
import com.clarifi.phoenix.ashes.common.IssueDataSlicedByDataItem;
import com.clarifi.phoenix.ashes.common.PhoenixDate;
import com.clarifi.phoenix.ashes.common.PhoenixDateRange;
import com.clarifi.phoenix.ashes.common.TimeSeriesDataCache;
import com.clarifi.phoenix.ashes.data.DataItemSlicesIndex;
import com.clarifi.phoenix.ashes.data.TimeSeriesDataKey;
import com.clarifi.phoenix.ashes.task.GetTimeSeries;
import org.apache.ignite.IgniteCompute;
import org.apache.logging.log4j.Logger;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Callable;

abstract class IssueTimeSeriesTask extends DecompTask<List<Integer>> {
    private static final Logger LOGGER = Logging.getLogger(IssueTimeSeriesTask.class);

    private final int issueId;
    private final int[] dataItems;
    private final IgniteCompute compute;
    private final StreamingSenderThread sender;

    public IssueTimeSeriesTask(final int issueId, final int[] dataItems,
                               final IgniteCompute compute, final StreamingSenderThread sender) {
        this.issueId = issueId;
        this.dataItems = dataItems;
        this.compute = compute;
        this.sender = sender;

        setComputeFunction(this::compute);
    }

    public TaskResult<List<Integer>> compute(final DecompTask<List<Integer>> task,
                                             final TaskContext<List<Integer>> context) throws Exception {
        task.prepareScatter(0, this::continuation, Unification.UniteOrFailOnFirstFailure);

        final IonSystem ion = IonSystemBuilder.standard().build();

        final List<Integer> results = new LinkedList<>();

        for (final int dataItemId : dataItems) {
            final TimeSeriesDataKey key = TimeSeriesDataCache.createKey(issueId, dataItemId);
            task.scatterFor(0, new Callable<List<Integer>>() {
                @Override
                public List<Integer> call() {
                    final DataItemSlicesIndex slices = compute.affinityCall(
                            TimeSeriesDataCache.getName(),
                            key,
                            new GetTimeSeries(issueId, dataItemId)
                    );

                    final ByteArrayOutputStream temp = new ByteArrayOutputStream();

                    if (slices != null && !slices.isEmpty()) {
                        for (final IssueDataSlicedByDataItem slice : slices.getAll()) {
                            // todo: aggregate data on the node for a single day
                            final PhoenixDateRange range = PhoenixDateRange.fromPackedValue(slice.getDateRange());
                            PhoenixDate date = range.getStart();

                            final double[] values = slice.getValues();
                            for (final double value : values) {
                                try {
                                    renderDataLine(slice, date, value, temp);

                                    temp.write(",\n".getBytes(StandardCharsets.UTF_8));
                                    final byte[] serialized = temp.toByteArray();

                                    sender.queueData(serialized);

                                    results.add(Integer.valueOf(serialized.length));
                                } catch (final Throwable err) {
                                    LOGGER.error("Error generating data line: {}", err);
                                } finally {
                                    temp.reset();
                                    date = date.plusDays(1);
                                }
                            }
                        }
                    }

                    return results;
                }
            });
        }

        task.scatterFullyDefined(0);

        return ContinuationResult.instanceOf();
    }

    private TaskResult<List<Integer>> continuation(final DecompTask<List<Integer>> task,
                                                   final ContinuationContext<List<Integer>> context,
                                                   final TaskResult<?>[] results) {
        final List<Integer> all = new LinkedList<>();

        for (final TaskResult<?> item : results) {
            if (item.isFailure()) {
                LOGGER.error("Failed to get time series data: {}", item);
                continue;
            }

            final SuccessfulResult<List<Integer>> result = (SuccessfulResult<List<Integer>>) item;

            all.addAll(result.result());
        }

        return SuccessfulResult.of(all);
    }

    protected abstract void renderDataLine(
            IssueDataSlicedByDataItem slice, PhoenixDate date, double value,  ByteArrayOutputStream stream) throws IOException;
}
