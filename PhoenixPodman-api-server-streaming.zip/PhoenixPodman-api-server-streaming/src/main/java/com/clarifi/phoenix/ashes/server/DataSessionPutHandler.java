package com.clarifi.phoenix.ashes.server;

import com.clarifi.phoenix.ashes.common.PackedDataSession;
import com.clarifi.phoenix.ashes.task.BuildDataSession;
import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;
import io.undertow.util.StatusCodes;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteCompute;
import org.apache.ignite.IgniteException;
import org.apache.ignite.lang.IgniteFuture;

import java.io.InputStream;
import java.util.Deque;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class DataSessionPutHandler extends CreateDataSessionHandler implements HttpHandler {
    private final ServerApp server;
    private int timeoutS = 5;

    public DataSessionPutHandler(final ServerApp server) {
        this.server = server;
    }

    @Override
    public void handleRequest(final HttpServerExchange exchange) throws Exception {
        handleParams(exchange);

        final InputStream input = exchange.getInputStream();
        final byte[] bytes = input.readAllBytes();

        final PackedDataSession.Reader reader = new PackedDataSession.IonReader();
        final PackedDataSession session = (PackedDataSession) reader.read(bytes);

        final Ignite ignite = server.getIgnite();
        final IgniteCache<UUID, PackedDataSession> cache = getOrCreateUserCache(ignite, session.getUserId().toString());
        if (cache.containsKey(session.getId())) {
            exchange.setStatusCode(StatusCodes.BAD_REQUEST);

            final String message = String.format("Data session with id '%s' already exists", session.getUserId());
            exchange.getResponseSender().send(message);
        } else {
            cache.put(session.getId(), session);
            /*
            * This combines the two calls to create an IgniteCompute instance that is restricted to the server nodes
            * in the cluster. This means that any computations submitted through this IgniteCompute instance (facade for executing
            * compute tasks in the cluster) will be executed on the server nodes only.
            * */
            final IgniteCompute compute = ignite.compute(ignite.cluster().forServers());

            final IgniteFuture<Boolean> future = compute.callAsync(new BuildDataSession(session, cache.getName()));
            try {
                final Boolean result = future.get(timeoutS, TimeUnit.SECONDS);
                sendSessionResult(session, result, exchange);
            } catch (final IgniteException ex) {
                // todo: look for a better way of detecting timeout
                if (!future.isCancelled() && !future.isDone()) {
                    sendSessionStatus(session, exchange);
                } else {
                    sendSessionError(session, ex, exchange);
                }
            } catch (final Throwable err) {
                err.printStackTrace(System.err);
            }
        }

        exchange.endExchange();
    }

    private void handleParams(final HttpServerExchange exchange) {
        final Map<String, Deque<String>> params = exchange.getQueryParameters();
        if (params == null || params.isEmpty()) {
            return;
        }

        final Deque<String> timeout = exchange.getQueryParameters().get("timeout");
        if (timeout != null && !timeout.isEmpty()) {
            timeoutS = Integer.parseInt(timeout.getFirst());
        }
    }
}
