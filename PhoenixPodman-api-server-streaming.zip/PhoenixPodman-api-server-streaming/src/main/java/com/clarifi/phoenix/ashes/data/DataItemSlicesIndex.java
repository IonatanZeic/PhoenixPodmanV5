package com.clarifi.phoenix.ashes.data;

import com.clarifi.phoenix.ashes.common.IssueDataSlicedByDataItem;
import com.clarifi.phoenix.ashes.common.PhoenixDate;
import com.clarifi.phoenix.ashes.common.PhoenixDateRange;

import java.util.ArrayList;
import java.util.List;

// todo: replace the list with custom index implementation that will keep track of sorted date ranges
// todo: to allow for faster lookups
public class DataItemSlicesIndex implements Cloneable {
    private List<IssueDataSlicedByDataItem> list;
    private long lastChangedAt;

    public DataItemSlicesIndex() {
        list = new ArrayList<>(4);
        lastChangedAt = 0L;
    }

    @Override
    public DataItemSlicesIndex clone() throws CloneNotSupportedException {
        super.clone();

        final DataItemSlicesIndex clone = new DataItemSlicesIndex();
        clone.list = new ArrayList<>(list);
        clone.lastChangedAt = lastChangedAt;

        return clone;
    }

    public long getLastChangedAt() {
        return lastChangedAt;
    }

    public boolean isEmpty() {
        return list.isEmpty();
    }

    public Iterable<IssueDataSlicedByDataItem> getAll() {
        return list;
    }

    public int size() {
        return list.size();
    }

    public void add(final IssueDataSlicedByDataItem item) {
        list.add(item);

        lastChangedAt = System.nanoTime();
    }

    public boolean hasEntriesFor(final PhoenixDateRange range) {
        for (final IssueDataSlicedByDataItem item : list) {
            final PhoenixDateRange candidate = PhoenixDateRange.fromPackedValue(item.getDateRange());
            if (range.equals(candidate)) {
                return true;
            } else if (candidate.includes(range)) {
                return true;
            }
        }

        return false;
    }

    public boolean hasEntryFor(final PhoenixDate date) {
        for (final IssueDataSlicedByDataItem item : list) {
           final PhoenixDateRange range = PhoenixDateRange.fromPackedValue(item.getDateRange());
           if (range.contains(date)) {
               return true;
           }
        }

        return false;
    }

    public boolean contains(final IssueDataSlicedByDataItem slice) {
        for (final IssueDataSlicedByDataItem item : list) {
            if (item.equals(slice)) {
                return true;
            } else if (item.contains(slice)) {
                return true;
            }
        }

        return false;
    }
}
