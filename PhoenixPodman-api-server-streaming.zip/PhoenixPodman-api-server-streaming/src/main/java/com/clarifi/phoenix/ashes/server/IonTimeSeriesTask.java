package com.clarifi.phoenix.ashes.server;

import com.amazon.ion.IonList;
import com.amazon.ion.IonSystem;
import com.amazon.ion.IonValue;
import com.amazon.ion.IonWriter;
import com.amazon.ion.system.IonSystemBuilder;
import com.amazon.ion.system.IonTextWriterBuilder;
import com.clarifi.phoenix.ashes.common.IssueDataSlicedByDataItem;
import com.clarifi.phoenix.ashes.common.PhoenixDate;
import org.apache.ignite.IgniteCompute;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.LinkedList;
import java.util.List;

public class IonTimeSeriesTask extends IssueTimeSeriesTask {
    private final List<IonValue> sequence;
    private final IonSystem ion;
    private final IonTextWriterBuilder builder;

    public IonTimeSeriesTask(final int issueId, final int[] dataItems,
                             final IgniteCompute compute,
                             final StreamingSenderThread sender) {
        super(issueId, dataItems, compute, sender);

        sequence = new LinkedList<>();

        ion = IonSystemBuilder.standard().build();
        builder = IonTextWriterBuilder.minimal();
        builder.setCharset(StandardCharsets.UTF_8);
    }

    @Override
    protected void renderDataLine(final IssueDataSlicedByDataItem slice,
                                  final PhoenixDate date,
                                  final double value,
                                  final ByteArrayOutputStream out) throws IOException {
        // todo: too much code duplication with JsonTimeSeriesTask; look into refactoring
        sequence.clear();
        sequence.add(ion.newInt(slice.getIssueId()));
        sequence.add(ion.newString(String.format("%04d-%02d-%02d", date.getYear(), date.getMonth(), date.getDayOfMonth())));
        sequence.add(ion.newInt(slice.getDataItemId()));
        sequence.add(ion.newDecimal(value));

        final IonWriter writer = builder.build(out);

        final IonList list = ion.newList(sequence);
        list.writeTo(writer);
        writer.flush();
    }
}
