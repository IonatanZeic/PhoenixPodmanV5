package com.clarifi.phoenix.ashes.task;

import com.clarifi.common.util.Logging;
import com.clarifi.concurrent.PoolSize;
import com.clarifi.concurrent.Unification;
import com.clarifi.concurrent.UnitedFuture;
import com.clarifi.concurrent.batch.BatchBuilder;
import com.clarifi.concurrent.batch.BatchingThreadPool;
import com.clarifi.concurrent.batch.DecompContinuousBatch;
import com.clarifi.concurrent.batch.task.*;
import com.clarifi.phoenix.ashes.common.*;
import com.clarifi.phoenix.ashes.data.DataItemSlicesIndex;
import com.clarifi.phoenix.ashes.data.TimeSeriesDataKey;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.cache.CachePeekMode;
import org.apache.ignite.configuration.CacheConfiguration;
import org.apache.ignite.lang.IgniteCallable;
import org.apache.ignite.resources.IgniteInstanceResource;
import org.apache.logging.log4j.Logger;

import javax.cache.Cache;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

public class BuildDataSession implements IgniteCallable<Boolean> {
    private static final Logger LOGGER = Logging.getLogger(BuildDataSession.class);

    public static final int TIME_SERIES_ISSUE_MULTIPLIER = 10_000;
    public static final int CROSS_SECTIONAL_ISSUE_MULTIPLIER = 20_000;
    public static final int YEAR_MULTIPLIER = 10_000;
    public static final int MONTH_MULTIPLIER = 100;
    public static final double DATE_DIVISOR = Math.pow(10, 8);

    private final PackedDataSession session;
    private final String cacheName;

    @IgniteInstanceResource
    Ignite ignite;

    private final CacheConfiguration<TimeSeriesDataKey, DataItemSlicesIndex> cfgTimeSeries;

    public BuildDataSession(final PackedDataSession session, final String cacheName) {
        this.session = session;
        this.cacheName = cacheName;

        cfgTimeSeries = TimeSeriesDataCache.getCacheConfig(2);
    }

    @Override
    public Boolean call() {
        final long startedAt = System.nanoTime();

        final IgniteCache<UUID, PackedDataSession> userDataSessionCache = ignite.cache(cacheName);
        session.setStatus(DataSession.Status.Loading);
        userDataSessionCache.replace(session.getId(), session);

        double elapsedMillis = (System.nanoTime() - startedAt) / 1_000_000d;
        LOGGER.info("Session {} created in {} seconds", session.getId(), Double.valueOf(elapsedMillis / 1000d));

        try {
            buildTimeSeries();
            //buildTimeSeriesUsingThreadingLibrary();
            // todo: intentionally iterating twice to lengthen the build process for testing
            buildCrossSectional();

            session.setStatus(DataSession.Status.Ready);

            elapsedMillis = (System.nanoTime() - startedAt) / 1_000_000d;
            LOGGER.info("Session {} validated/loaded in {} seconds", session.getId(), Double.valueOf(elapsedMillis / 1000d));
        } catch (final Throwable err) {
            err.printStackTrace(System.err);

            session.setStatus(DataSession.Status.Failed);

            LOGGER.info("Session {} validation failed", session.getId());
        } finally {
            userDataSessionCache.replace(session.getId(), session);
        }

        LOGGER.info("User {} has {} data sessions", session.getUserId(), userDataSessionCache.size());

        return Boolean.TRUE;
    }

    private void buildTimeSeries() {
        int hits = 0;
        int misses = 0;

        for (final int issueId : session.getIssues()) {
            final IssueDataSlicedByDataItem.Builder builder = new IssueDataSlicedByDataItem.Builder();
            builder.setIssueId(issueId);
            builder.setRange(session.getRange());

            for (final int dataItemId : session.getDataItems()) {
                builder.setDataItemId(dataItemId);

                // todo: this checks for the entire range being cached; we need to improve this to
                // todo: support sub ranges and partial caching
                final boolean isCached = validate(issueId, dataItemId, session.getRange());
                if (!isCached) {
                    misses++;

                    PhoenixDate date = session.getRange().getStart();
                    while (session.getRange().contains(date)) {
                        final double left = issueId * TIME_SERIES_ISSUE_MULTIPLIER + dataItemId;
                        final double right = (date.getYear() * YEAR_MULTIPLIER + date.getMonth() * MONTH_MULTIPLIER + date.getDayOfMonth()) / DATE_DIVISOR;
                        builder.setValue(date, left + right);

                        date = date.plusDays(1);
                    }

                    final IssueDataSlicedByDataItem slice = builder.build();
                    build(slice);
                } else {
                    hits++;
                }
            }
        }

        LOGGER.info("TimeSeries cache size: {}", ignite.cache(cfgTimeSeries.getName()).size(CachePeekMode.ALL));
        LOGGER.info("TimeSeries cache hits {}, misses {}", hits, misses);
    }

    private boolean validate(final int issueId, final int dataItemId, final PhoenixDateRange range) {
        final TimeSeriesDataKey key = TimeSeriesDataCache.createKey(issueId, dataItemId);
        final Cache<TimeSeriesDataKey, DataItemSlicesIndex> cache = ignite.getOrCreateCache(cfgTimeSeries);

        final DataItemSlicesIndex index = cache.get(key);
        if (index == null) {
            return false;
        } else if (index.isEmpty()) {
            return false;
        }

        return index.hasEntriesFor(range);
    }

    private void build(final IssueDataSlicedByDataItem slice) {
        final TimeSeriesDataKey key = TimeSeriesDataCache.createKey(slice.getIssueId(), slice.getDataItemId());
        final Cache<TimeSeriesDataKey, DataItemSlicesIndex> cache = ignite.getOrCreateCache(cfgTimeSeries);

        boolean completed = false;
        while (!completed) {
            final DataItemSlicesIndex index = cache.get(key);
            if (index == null || index.isEmpty()) {
                final DataItemSlicesIndex newIndex = new DataItemSlicesIndex();
                newIndex.add(slice);

                completed = cache.putIfAbsent(key, newIndex);
            } else {
                final DataItemSlicesIndex newIndex;
                try {
                    newIndex = index.clone();
                    newIndex.add(slice);

                    completed = cache.replace(key, index, newIndex);
                } catch (final CloneNotSupportedException err) {
                    err.printStackTrace(System.err);

                    break;
                }
            }
        }
    }

    private void buildTimeSeriesUsingThreadingLibrary() {
        BatchingThreadPool pool = BatchingThreadPool.builder("AppThreadPool", PoolSize.cached(2, 16)).build();
        //use a completionFunction, so we can get our result from the batch
        final DecompContinuousBatch<HitMissCount, HitMissCount> processingBatch =
                BatchBuilder.builderForCollector(Unification.UniteOrFailOnFirstFailure,
                                Collectors.reducing(new HitMissCount(0,0), (hitMissCount, hitMissCount2) -> new HitMissCount(hitMissCount.getHits() +
                                        hitMissCount2.getHits(), hitMissCount.getMisses() + hitMissCount2.getMisses())))
                        .forBatchType_DecompContinuous().buildForCollectorOrCompleterFunction();

        UnitedFuture<HitMissCount, HitMissCount> processFut = processingBatch.submitToPool(pool);

        // create the batches using issues,
        final Cache<TimeSeriesDataKey, DataItemSlicesIndex> cache = ignite.getOrCreateCache(cfgTimeSeries);

        int [] issues = session.getIssues();
        int threshold = 1000;
        processingBatch.addCallable(new BuildTimeSeriesSessionTask(processingBatch, cache, 0, issues.length, issues, threshold));

        processingBatch.batchFullyDefined();
        HitMissCount result = null;
        try {
            result = processFut.get();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        } catch (ExecutionException e) {
            throw new RuntimeException(e);
        }

        LOGGER.info("TimeSeries cache size: {}", ignite.cache(cfgTimeSeries.getName()).size(CachePeekMode.ALL));
        LOGGER.info("'TL' TimeSeries cache hits {}, misses {}", result.getHits(), result.getMisses());
    }

    private final class BuildTimeSeriesSessionTask extends DecompTask<HitMissCount> {
        private final Cache<TimeSeriesDataKey, DataItemSlicesIndex> cache;
        private final DecompContinuousBatch<HitMissCount,HitMissCount> processingBatch;
        private final int start;
        private final int end;
        private final int [] issues;
        private final int threshold;
        BuildTimeSeriesSessionTask(DecompContinuousBatch<HitMissCount,HitMissCount> processingBatch,
                                   Cache<TimeSeriesDataKey, DataItemSlicesIndex> cache, int start, int end, int [] issues, int threshold){
            this.processingBatch = processingBatch;
            this.cache = cache;
            this.start = start;
            this.end = end;
            this.issues = issues;
            this.threshold = threshold;
            setComputeFunction(this::compute);
        }

        public TaskResult<HitMissCount> compute(final DecompTask<HitMissCount> task,
                                                final TaskContext<HitMissCount> context){

            task.prepareScatter(0, this::continuation, Unification.UniteOrFailOnFirstFailure);

            HitMissCount hitMissCount = new HitMissCount(0,0);

            int nextStart = start + threshold;
            if (nextStart < end) {
                processingBatch.addCallable(new BuildTimeSeriesSessionTask(processingBatch, cache, nextStart, end, issues, threshold));
                nextStart = start + threshold;
            }

            for(int i = start; i < Math.min(nextStart, end); i++){
                int issueId = issues[i];
                final IssueDataSlicedByDataItem.Builder builder = new IssueDataSlicedByDataItem.Builder();
                builder.setIssueId(issueId);
                builder.setRange(session.getRange());

                for (final int dataItemId: session.getDataItems()) {
                    builder.setDataItemId(dataItemId);

                    final TimeSeriesDataKey key = new TimeSeriesDataKey(issueId, dataItemId);

                    final DataItemSlicesIndex index = cache.get(key);

                    if (index == null || index.isEmpty()) {

                        PhoenixDate date = session.getRange().getStart();
                        while (session.getRange().contains(date)) {
                            final double left = issueId * TIME_SERIES_ISSUE_MULTIPLIER + dataItemId;
                            final double right = (date.getYear() * YEAR_MULTIPLIER + date.getMonth() * MONTH_MULTIPLIER + date.getDayOfMonth()) / DATE_DIVISOR;
                            builder.setValue(date, left + right);

                            date = date.plusDays(1);
                        }

                        final IssueDataSlicedByDataItem slice = builder.build();
                        build(slice);
                        hitMissCount.setMisses(hitMissCount.getMisses() + 1);
                    }
                    else {
                        hitMissCount.setHits(hitMissCount.getHits() + 1);
                    }
                }
            }
            task.scatterFor(0, () -> hitMissCount);

            task.scatterFullyDefined(0);

            return ContinuationResult.instanceOf();
        }

        private TaskResult<?> continuation(final DecompTask<HitMissCount> task,
                                           final ContinuationContext<HitMissCount> context,
                                           final TaskResult<?>[] results) throws Exception{

            HitMissCount result = new HitMissCount(0,0);
            int hits = 0, misses = 0;
            for (int i = 0, n = results.length; i < n; i++)
            {
                TaskResult<?> res = results[i];
                if (res.isFailure())
                    throw ((FailedResult<?>)res).errAsException();

                SuccessfulResult<HitMissCount> sRes = (SuccessfulResult<HitMissCount>)res;
                hits += sRes.result().getHits();
                misses += sRes.result().getMisses();
            }
            result.setHits(hits);
            result.setMisses(misses);

            return SuccessfulResult.of(result);
        }
    }

    class HitMissCount{
        private int hits;
        private int misses;
        public HitMissCount(int hits, int misses){
            this.hits = hits;
            this.misses = misses;
        }
        public int getHits(){
            return this.hits;
        }
        public int getMisses(){
            return this.misses;
        }
        public void setHits(int hits){
            this.hits = hits;
        }
        public void setMisses(int misses){
            this.misses = misses;
        }
    }

    private void buildCrossSectional() {
//        final CacheConfiguration<CrossSectionalDataKey, List<IssueDataSlicedByDate>> cfgCrossSectional = getCrossSectionalConfig();
//
//        int hits = 0;
//        int misses = 0;
//
//        for (final int issueId: session.getIssues()) {
//            final IssueDataSlicedByDate.Builder builder = new IssueDataSlicedByDate.Builder();
//            builder.setIssueId(issueId);
//
//            PhoenixDate date = session.getRange().getStart();
//            while (session.getRange().contains(date)) {
//                builder.setDate(date);
//
//                final double right = (date.getYear() * YEAR_MULTIPLIER + date.getMonth() * MONTH_MULTIPLIER + date.getDayOfMonth()) / DATE_DIVISOR;
//                for (final int dataItemId: session.getDataItems()) {
//                    final double left = issueId * CROSS_SECTIONAL_ISSUE_MULTIPLIER + dataItemId;
//
//                    final int index = builder.addDataItem(dataItemId);
//                    builder.setValue(index, left + right);
//                }
//
//                final IssueDataSlicedByDate slice = builder.build();
//
//                final Cache<CrossSectionalDataKey, List<IssueDataSlicedByDate>> cache = ignite.getOrCreateCache(cfgCrossSectional);
//                final CrossSectionalDataKey key = new CrossSectionalDataKey(issueId, date.getPackedValue());
//
//                final List<IssueDataSlicedByDate> list = cache.get(key);
//                if (list == null || list.isEmpty()) {
//                    final List<IssueDataSlicedByDate> newList = new LinkedList<>();
//                    newList.add(slice);
//
//                    cache.put(key, newList);
//                    misses++;
//                } else {
//                    boolean found = false;
//
//                    for (final IssueDataSlicedByDate item: list) {
//                        if (item.equals(slice)) {
//                            found = true;
//                            hits++;
//
//                            break;
//                        } else if (item.contains(slice)) {
//                            found = true;
//                            hits++;
//
//                            break;
//                        }
//                    }
//
//                    if (!found) {
//                        list.add(slice);
//
//                        // todo: add semaphore to prevent concurrent modification
//                        cache.replace(key, list);
//                    }
//                }
//
//                date = date.plusDays(1);
//            }
//        }
//
//        System.out.printf("CrossSectional cache size: %d\n", ignite.cache(cfgCrossSectional.getName()).size(CachePeekMode.ALL));
//        System.out.printf("CrossSectional cache hits %d, misses %d\n", hits, misses);
    }
}
