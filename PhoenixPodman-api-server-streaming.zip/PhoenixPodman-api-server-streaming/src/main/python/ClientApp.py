import json
from urllib import parse, request
import time
import gzip

# Create a new data session using a POST request
small = {'user': "eca8b35b-f6c3-4a5f-88ec-f9a2d2bf9e9f", \
	'range': {'start-date': {'year': 2023, 'month': 2, 'day': 13}, \
	'end-date': {'year': 2024, 'month': 12, 'day': 31}}, \
	'dataItems': [100, 101, 102], \
	'issues': [1000, 1001, 1002, 1003, 1004, 1005], ' \
	lastAccessedAt': int(time.time() * 1000)}
small_as_json = json.dumps(small)

post = request.Request('http://localhost:8081/api2/data-session/new', data=small_as_json.encode('utf-8'))
post.add_header('Content-Encoding', 'text/json')

response = request.urlopen(post)
content = response.read()

session = json.loads(content.decode('utf-8'))
print(session)

# Get data session from server using it's uid and user's uid
url_get = 'http://localhost:8081/api2/data-session/{id}?userId={user}'.format(**session)
get = request.Request(url_get)
get.add_header('Accept', 'text/json')
get.add_header('Accept-Encoding', 'gzip')

compressed = request.urlopen(get).read()
decompressed = gzip.decompress(compressed)

copy = json.loads(decompressed)
print(copy)

# Get time series data for session
url_timeseries = 'http://localhost:8081/api2/time-series/1001/102'
timeseries = request.Request(url_timeseries)

ts_response = request.urlopen(timeseries)
slices = ts_response.read()
# print(slices)

# Count issues for user's data sessions
url_count = 'http://localhost:8081/api2/data-sessions/count-issues/{user}'.format(**copy)
count = request.Request(url_count)

issues = request.urlopen(count).read()
print(issues.decode('utf-8'))
