package com.phoenix;

import com.amazon.ion.*;
import com.amazon.ion.system.IonSystemBuilder;

import java.io.InputStream;

public class CmdResult {
    public enum Status
    {
        success,
        fail,
        inProgress,
        terminated
    }
    int transactionId;
    private Status status;
    private String desc;
    private Object result;
    private Timestamp lastUpdated;
    public void setStatus(String status) {
        this.status = Status.valueOf(status);
    }
    public Status getStatus() {
        return status;
    }
    public void setStatus(Status status) {
        this.status = status;
    }
    public Timestamp getLastUpdated() {
        return lastUpdated;
    }
    public void setLastUpdated(Timestamp lastUpdated) {
        this.lastUpdated = lastUpdated;
    }
    public String getDesc() {
        return desc;
    }
    public void setDesc(String desc) {
        this.desc = desc;
    }
    public Object getResult() {
        return result;
    }
    public void setResult(Object result) {
        this.result = result;
    }
    public int getTransactionId() {
        return transactionId;
    }
    public void setTransactionId(int transactionId) {
        this.transactionId = transactionId;
    }
    CmdResult(int transactionId, String desc, Object result, String status, Timestamp lastUpdated){
        this.transactionId = transactionId;
        this.desc = desc;
        this.result = result;
        this.status = Status.valueOf(status);
        this.lastUpdated = lastUpdated;
    }
    CmdResult(){}
    static CmdResult convertFromGZippedIonFormat(InputStream inputStream) {
        IonSystem ionSystem = IonSystemBuilder.standard().build();

        IonReader ionReader = ionSystem.newReader(inputStream);

        ionReader.next();
        ionReader.stepIn();
        Timestamp lastUpdated = null;
        String status = null;
        Object result = null;
        int transactionId = 0;
        String desc = "";
        while(ionReader.next() != null){
            char fieldName = ionReader.getFieldName().charAt(0);
            switch(fieldName){
                case Constants.transactionId:
                    transactionId = ionReader.intValue();
                    break;
                case Constants.status:
                    status = ionReader.stringValue();
                    break;
                case Constants.lastUpdated:
                    lastUpdated = ionReader.timestampValue();
                    break;
                default:
                    ionReader.stepIn();

                    while (ionReader.next() != null) {
                        char fieldNameForInnerStruct = ionReader.getFieldName().charAt(0);
                        switch (fieldNameForInnerStruct) {
                            case Constants.result:
                                if(ionReader.getType() == IonType.STRUCT){
                                    StringBuilder stringBuilder = new StringBuilder();
                                    stringBuilder.append("{");

                                    ionReader.stepIn();

                                    while(ionReader.next() != null){
                                        String ObjFieldName= ionReader.getFieldName();
                                        Object fieldValue = readIonValue(ionReader, ionSystem);

                                        stringBuilder.append("\"" + ObjFieldName + "\": ");
                                        stringBuilder.append("\"" + fieldValue + "\"");
                                        stringBuilder.append(",");
                                    }
                                    ionReader.stepOut();

                                    if(stringBuilder.length() > 1)
                                        stringBuilder.setLength(stringBuilder.length() - 1);
                                    stringBuilder.append("}");
                                    result = stringBuilder.toString();
                                    break;
                                }
                                result = ionReader.doubleValue();
                                break;
                            case Constants.resultDescription:
                                desc = ionReader.stringValue();
                                break;
                        }
                    }
                    ionReader.stepOut();
                }
            }

        return new CmdResult(transactionId, desc, result, status, lastUpdated);
    }

    private static Object readIonValue(IonReader ionReader, IonSystem ionSystem) {
        IonType ionType = ionReader.getType();

        switch (ionType) {
            case STRING:
                return ionReader.stringValue();
            case INT:
                return ionReader.bigIntegerValue();
            // Add more cases for other data types as needed
            default:
                throw new IllegalArgumentException("Unsupported Ion type: " + ionType);
        }
    }
}