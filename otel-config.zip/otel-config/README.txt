this module does not belong to apache ignite
It contains the necessary files to start prometheus, otel and zipkin containers on docker
(for podman -> create a podman-compose.yml and modify the content inside if needed)

verify where jmx folder is located, if non existent downlaod it from my Github

Dont forget to change the paths of prometheus.yml and otellcollector.yml in docker.compose

run docker compose up(or podman ...)

In Ignite root directory execute:
bin/ignite.sh
-J-javaagent:/pathul/unde/se/gaseste/jmx_prometheus_javaagent.jar=<numarul-por
tului>:/pathul/unde/se/gaseste/jmx-exporter-config.yml

Example:
bin/ignite.sh -J-javaagent:/home/ioni/Desktop/ignite-master2/ignite-master/jmx/jmx_prometheus_javaagent-1.0.1.jar=1099:/home/ioni/Desktop/ignite-master2/ignite-master/jmx/jmx-exporter-config.yml

Change the port number accordingly to the number of the port/ports you have set up in prometheus.yml

then you can acces zipkin (http://localhost:9411/zipkin) and prometheus  (http://localhost:9090)and see metrics and traces
