package com.clarifi.phoenix.ashes.server;

import com.clarifi.common.util.Logging;
import com.clarifi.phoenix.ashes.common.DataSession;
import com.clarifi.phoenix.ashes.common.PackedDataSession;
import com.clarifi.phoenix.ashes.common.PhoenixMimeTypes;
import com.clarifi.phoenix.ashes.task.UpdateDataSessionTimestamp;
import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;
import io.undertow.util.*;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteCompute;
import org.apache.logging.log4j.Logger;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.zip.GZIPOutputStream;

public class DataSessionGetHandler implements HttpHandler {
    private static final Logger LOGGER = Logging.getLogger(DataSessionGetHandler.class);

    private final ServerApp server;

    public DataSessionGetHandler(final ServerApp server) {
        this.server = server;
    }

    @Override
    public void handleRequest(final HttpServerExchange exchange) {
        //-- Data sessionId is in the path (REST request)
        PathTemplateMatch pathMatch = exchange.getAttachment(PathTemplateMatch.ATTACHMENT_KEY);
        String sessionId = pathMatch.getParameters().get("sessionId");

        //-- UserId is passed as a query parameter
        final String userId = exchange.getQueryParameters().get("userId").getFirst();

        final Ignite ignite = server.getIgnite();

        final String userCacheName = String.format(
                "%s:%s", ServerApp.PREFIX_CACHE_USER_DATA_SESSIONS, userId);

        final IgniteCache<UUID, PackedDataSession> userDataSessionCache = ignite.cache(userCacheName);
        if (userDataSessionCache == null) {
            exchange.setStatusCode(StatusCodes.NOT_FOUND);
            exchange.getResponseSender().send(String.format("User with id '%s' does have any sessions", userId));
            exchange.endExchange();

            return;
        }

        final DataSession session = userDataSessionCache.get(UUID.fromString(sessionId));
        if (session == null) {
            exchange.setStatusCode(StatusCodes.NOT_FOUND);
            exchange.getResponseSender().send(String.format(
                    "Data session '%s' does not exist for user '%s'", sessionId, userId));
            exchange.endExchange();

            return;
        }

        final ExecutorService executor = server.getExecutor();
        exchange.dispatch(executor, new Runnable() {
            @Override
            public void run() {
                final IgniteCompute compute = ignite.compute(ignite.cluster().forServers());
                compute.runAsync(new UpdateDataSessionTimestamp(userId, sessionId));

                final PackedDataSession.Writer writer = getWriter(exchange.getRequestHeaders(), session);
                try {
                    final ByteArrayOutputStream output = new ByteArrayOutputStream();
                    if (acceptsGZIP(exchange.getRequestHeaders())) {
                        writer.write(new GZIPOutputStream(output));

                        exchange.getResponseHeaders().put(Headers.CONTENT_ENCODING, "gzip");
                    } else {
                        writer.write(output);
                    }

                    final byte[] payload = output.toByteArray();

                    exchange.setStatusCode(StatusCodes.OK);
                    exchange.setResponseContentLength(payload.length);

                    exchange.getResponseHeaders().put(Headers.CONTENT_LENGTH, Integer.toString(payload.length));
                    exchange.getResponseHeaders().put(Headers.CONTENT_TYPE, writer.getMimeType());

                    exchange.getResponseSender().send(ByteBuffer.wrap(payload));

                    LOGGER.info(
                            "{Thread:{}} Data session sent: {}",
                            Thread.currentThread().getName(),
                            session
                    );
                } catch (final Throwable err) {
                    exchange.setStatusCode(StatusCodes.INTERNAL_SERVER_ERROR);

                    err.printStackTrace(System.err);
                } finally {
                    exchange.endExchange();
                }

            }
        });
    }

    private boolean acceptsGZIP(final HeaderMap headers) {
        final HeaderValues encoding = headers.get(Headers.ACCEPT_ENCODING);
        if (encoding == null || encoding.isEmpty()) {
            return false;
        }

        // todo: find faster way to check for gzip support
        final String[] encodings = encoding.getFirst().split(",");
        for (final String enc : encodings) {
            if (enc.trim().equalsIgnoreCase("gzip")) {
                return true;
            }
        }

        return false;
    }

    private PackedDataSession.Writer getWriter(final HeaderMap headers, final DataSession session) {
        final HeaderValues encoding = headers.get(Headers.ACCEPT);
        if (encoding == null || encoding.isEmpty()) {
            return new PackedDataSession.JsonWriter(session);
        }

        if (encoding.contains(PhoenixMimeTypes.TEXT_JSON)) {
            return new PackedDataSession.JsonWriter(session);
        }

        if (encoding.contains(PhoenixMimeTypes.TEXT_ION)) {
            return new PackedDataSession.IonWriter(session);
        }

        if (encoding.contains(PhoenixMimeTypes.BYTES_ION) || encoding.contains(PhoenixMimeTypes.APPLICATION_ION)) {
            return new PackedDataSession.BinaryIonWriter(session);
        }

        return new PackedDataSession.JsonWriter(session);
    }
}
