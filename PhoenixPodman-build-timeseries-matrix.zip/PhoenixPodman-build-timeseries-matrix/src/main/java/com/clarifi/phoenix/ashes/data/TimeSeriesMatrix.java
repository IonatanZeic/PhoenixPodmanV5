package com.clarifi.phoenix.ashes.data;

import com.clarifi.phoenix.ashes.common.PhoenixDate;
import com.clarifi.phoenix.ashes.common.PhoenixDateRange;

import java.nio.ByteBuffer;
import java.util.*;

public class TimeSeriesMatrix {
    private final int issueId;
    private final int dateRange;

    private int[] dataItems;
    private byte[] data;

    public TimeSeriesMatrix(final int issueId, final int range) {
        this.issueId = issueId;
        this.dateRange = range;

        dataItems = new int[] {};
        data = new byte[] {};
    }

    public int getIssueId() {
        return issueId;
    }

    public int getDateRange() {
        return dateRange;
    }

    public int[] getDataItems() {
        return dataItems;
    }

    public void setDataItems(final int[] dataItems) {
        this.dataItems = dataItems;
    }

    public void setData(final byte[] data) {
        this.data = data;
    }

    public int getDataLength() {
        return data.length;
    }

    public double[] getValuesFor(final char date) {
        final PhoenixDateRange range = PhoenixDateRange.fromPackedValue(dateRange);
        final int index = range.getDaysSinceStart(PhoenixDate.fromPackedValue(date));

        final double[] result = new double[dataItems.length];
        final int rowLength = range.getDaysInRange() * Double.BYTES;

        final ByteBuffer buffer = ByteBuffer.wrap(data);
        for (int idx = 0; idx < dataItems.length; idx++) {
            result[idx] = buffer.getDouble(idx * rowLength + index * Double.BYTES);
        }

        return result;
    }

    public static class Builder {
        private final int issueId;
        private final PhoenixDateRange range;

        private final List<Integer> keys;
        private final Map<Integer, double[]> keyToValue;
        private final int days;

        public Builder(final int issueId, final int range) {
            this.issueId = issueId;
            this.range = PhoenixDateRange.fromPackedValue(range);

            keys = new ArrayList<>();
            keyToValue = new HashMap<>();
            days = this.range.getDaysInRange();
        }

        public void addMissingValues(final int dataItemId) {
            final Integer key = Integer.valueOf(dataItemId);
            keys.add(key);

            final double[] empty = new double[days];
            Arrays.fill(empty, Double.NaN);

            keyToValue.put(key, empty);
        }

        public void addValues(final int dataItemId, final double[] values) {
            final Integer key = Integer.valueOf(dataItemId);
            keys.add(key);

            keyToValue.put(key, values);
        }

        public TimeSeriesMatrix build() {
            keys.sort(new Comparator<Integer>() {
                @Override
                public int compare(final Integer o1, final Integer o2) {
                    return Integer.compare(o1, o2);
                }
            });

            final TimeSeriesMatrix result = new TimeSeriesMatrix(issueId, range.getPackedValue());
            result.setDataItems(keys.stream().mapToInt(Integer::intValue).toArray());

            final ByteBuffer buffer = ByteBuffer.allocate(keys.size() * days * Double.BYTES);
            for (final Integer dataItemId : keys) {
                double[] values = keyToValue.get(dataItemId);
                for (double value : values) {
                    buffer.putDouble(value);
                }
            }

            buffer.flip();
            final byte[] data = buffer.array();
            result.setData(data);

            return result;
        }
    }
}
