package com.clarifi.phoenix.ashes.task;

import com.clarifi.phoenix.ashes.common.Common;
import com.clarifi.phoenix.ashes.data.IssueCalculationResult;
import com.clarifi.phoenix.ashes.data.TimeSeriesData;
import com.clarifi.phoenix.ashes.data.TimeSeriesDataCache;
import com.clarifi.phoenix.ashes.data.TimeSeriesDataKey;
import org.apache.ignite.*;
import org.apache.ignite.cache.CachePeekMode;
import org.apache.ignite.cache.affinity.Affinity;
import org.apache.ignite.configuration.IgniteConfiguration;
import org.apache.ignite.lang.IgniteCallable;
import org.apache.ignite.resources.IgniteInstanceResource;

import java.util.*;


/**
 * A computation tasks computes a sum of data items for each issue
 */
class Sum2Task implements IgniteCallable<IssueCalculationResult> {
  private final int _resultItemId;
  private final int[] _issueIds;
  private final int[] _dataItemRange;

  @IgniteInstanceResource
  Ignite ignite;

  public Sum2Task(int resultItemId, int[] issueIds, int[] dataItemRange) {
    _resultItemId = resultItemId;

    _issueIds = issueIds;

    _dataItemRange = new int[2];
    _dataItemRange[0] = dataItemRange[0];
    _dataItemRange[1] = dataItemRange[1];
  }

  @Override
  public IssueCalculationResult call() throws Exception
  {
    System.out.println(">> Executing the Sum2 Task");

    UUID nodeId = ignite.cluster().localNode().id();
    System.out.println("\tNode ID: " + nodeId);

    IgniteCache<TimeSeriesDataKey, TimeSeriesData> tsCache = ignite.cache(Common.TIMESERIES_DATA_CACHE);

    if (tsCache == null) {
      throw new IllegalStateException("Time series data cache " + Common.TIMESERIES_DATA_CACHE + " is not found, exiting");
    }

    IssueCalculationResult result = sumDataItems(tsCache);

    return result;
  }

  private IssueCalculationResult sumDataItems(IgniteCache<TimeSeriesDataKey, TimeSeriesData> tsCache)
  {
    IssueCalculationResult result = new IssueCalculationResult(_issueIds.length);
    for (int i = 0; i < _issueIds.length; ++i) {
      int issueId = _issueIds[i];
      TimeSeriesData issueResult = sumDataItems(tsCache, issueId);
      result.issueIds[i] = issueId;
      result.data[i] = issueResult;
    }

    return result;
  }

  private TimeSeriesData sumDataItems(IgniteCache<TimeSeriesDataKey, TimeSeriesData> tsCache, int issueId) {
    int startItem = _dataItemRange[0];
    int stopItem = _dataItemRange[1];

    TimeSeriesData result = null;

    for (int i = startItem; i <= stopItem; ++i) {
      int dataItemId = TimeSeriesDataCache.generateDataItemId(i);
      TimeSeriesDataKey key = new TimeSeriesDataKey(issueId, dataItemId);

      TimeSeriesData ts = tsCache.localPeek(key, CachePeekMode.PRIMARY);
      if (ts == null) {
        return null;
      }

      if (result == null) {
        result = new TimeSeriesData(ts);
      }
      else {
        add(result, ts);
      }
    }

    System.out.println("\tProcessed issueId = " + issueId);

    return result;
  }

  private static void add(TimeSeriesData result, TimeSeriesData ts) {
    for (int i = 0; i < result.values.length; ++i) {
      result.values[i] += ts.values[i];
    }
  }

  public static void main(String[] args) throws IgniteException {
    IgniteConfiguration cfg = Common.igniteClientConfiguration();

    // Starting the node
    Ignite ignite = Ignition.start(cfg);

    try {
      int[] dataRange = new int[] {1, 2};
      int[] issueRange = new int[] {1, 1000};

      int[] issueIds = {TimeSeriesDataCache.generateIssueId(1)};

      int resultItemId = TimeSeriesDataCache.generateDerivedDataItemId(2);
      long startTime = System.currentTimeMillis();

      IgniteCompute compute = ignite.compute();

      List<String> caches = Collections.singletonList(Common.TIMESERIES_DATA_CACHE);

      // get the affinity function configured for the cache
      Affinity<TimeSeriesDataKey> affinityFunc = ignite.affinity(Common.TIMESERIES_DATA_CACHE);

      // this map stores collections of keys for each partition
      HashMap<Integer, List<Integer>> partMap = new HashMap<>();
      int dataItemId = TimeSeriesDataCache.generateDataItemId(dataRange[0]);
      for (int i = issueRange[0]; i <= issueRange[1]; ++i) {
        int issueId = TimeSeriesDataCache.generateIssueId(i);
        TimeSeriesDataKey key = new TimeSeriesDataKey(issueId, dataItemId);
        int partId = affinityFunc.partition(key);
        List<Integer> keysByPartition = partMap.computeIfAbsent(partId, k -> new ArrayList<>());
        keysByPartition.add(issueId);
      }

      // iterate over all partitions
      List<IssueCalculationResult> results = new ArrayList<>(partMap.size());
      for (Map.Entry<Integer, List<Integer>> pair : partMap.entrySet()) {
        List<Integer> localIssueIdList = pair.getValue();
        int[] localIssueIds = new int[localIssueIdList.size()];
        for (int i = 0; i < localIssueIdList.size(); ++i) {
          localIssueIds[i] = localIssueIdList.get(i);
        }
        TimeSeriesDataKey key = new TimeSeriesDataKey(localIssueIds[0], dataItemId);

        // send a task that gets specific keys for the partition
        IgniteCallable<IssueCalculationResult> task = new Sum2Task(resultItemId, localIssueIds, dataRange);

        IssueCalculationResult sums = compute.affinityCall(caches, key, task);
        results.add(sums);
      }

      long stopTime = System.currentTimeMillis();


      System.out.println("Sum2 results: num = " + results.size());
      IssueCalculationResult sums = results.get(0);
      System.out.println("\tnumIssues: " + sums.numIssues);
      System.out.println("\tdata[0]: " + sums.data[0]);

      long execTime = stopTime - startTime;
      System.out.println(">> Compute task is executed, check for output on the server nodes.");
      System.out.println(">> Execution time is " + execTime + " ms");

    }
    finally {
      // Disconnect from the cluster.
      ignite.close();
    }
  }

}
