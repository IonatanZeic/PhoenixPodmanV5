package com.clarifi.phoenix.ashes.common;

public final class PhoenixMimeTypes {
    public static final String APPLICATION_ION = "application/ion";
    public static final String TEXT_ION = "text/ion";
    public static final String TEXT_JSON = "text/json";
    public static final String BYTES_ION = "application/ion";
}
