package com.clarifi.phoenix.ashes.task;

import com.clarifi.common.util.Logging;
import com.clarifi.phoenix.ashes.common.TimeSeriesDataCache;
import com.clarifi.phoenix.ashes.data.DataItemSlicesIndex;
import com.clarifi.phoenix.ashes.data.TimeSeriesDataKey;
import org.apache.ignite.Ignite;
import org.apache.ignite.lang.IgniteCallable;
import org.apache.ignite.resources.IgniteInstanceResource;
import org.apache.logging.log4j.Logger;

import javax.cache.Cache;

public class GetTimeSeries implements IgniteCallable<DataItemSlicesIndex> {
    private static final Logger LOGGER = Logging.getLogger(GetTimeSeries.class);

    private final int issueId;
    private final int dataItemId;

    @IgniteInstanceResource
    private Ignite ignite;

    public GetTimeSeries(final int issueId, final int dataItemId) {
        this.issueId = issueId;
        this.dataItemId = dataItemId;
    }

    @Override
    public DataItemSlicesIndex call() {
        final TimeSeriesDataKey key = TimeSeriesDataCache.createKey(issueId, dataItemId);

        final Cache<TimeSeriesDataKey, DataItemSlicesIndex> cache = ignite.cache(TimeSeriesDataCache.getName());
        final DataItemSlicesIndex index = cache.get(key);
        if (index == null || index.isEmpty()) {
            return null;
        }

        LOGGER.info(
                "{Thread:{}} {} cached slice(s) for issue={} and dataItem={}",
                Thread.currentThread().getName(),
                index.size(),
                key.issueId,
                key.dataItemId
        );

        return index;
    }
}
