package com.clarifi.phoenix.ashes.node;

import com.clarifi.common.application.App;
import com.clarifi.common.util.Logging;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteServices;
import org.apache.ignite.Ignition;
import org.apache.ignite.configuration.IgniteConfiguration;
import org.apache.logging.log4j.Logger;

import java.nio.file.Path;

public class NodeApp {
    private static final Logger LOGGER = Logging.getLogger(NodeApp.class);

    private volatile boolean stopped;
    private IgniteServices services;
    private Ignite ignite;
    private int serverId;

    public NodeApp() {
        stopped = false;
    }

    public boolean isStopped() {
        return stopped;
    }

    public static void main(final String[] args) throws Throwable {
        App.initBeforeAnythingElse(args, 0, "Node App", "1.0.0");

        final NodeApp node = new NodeApp();
        node.serverId = Integer.parseInt(args[0]);

        final App app = App.appMain(node::startup, node::shutdown);
    }

    private void startup(){
        final IgniteConfiguration cfg = new IgniteConfiguration();

        // we do not need to explicitly set it to false, since nodes are started in server mode by default
        cfg.setClientMode(false);

        /*
        * if we need to dynamically load new classes or update existing across the cluster without restarting nodes.
        * Since we are deploying compute tasks, closures or services that may not be present on all nodes, peer class loading ensures
        * that all nodes can execute these tasks by loading the necessary classes from other nodes.
        * */
        cfg.setPeerClassLoadingEnabled(true);

        final String serverName = "server-" + serverId;
        cfg.setIgniteInstanceName(serverName);
        cfg.setWorkDirectory(Path.of(System.getProperty("java.io.tmpdir"), serverName).toString());

        ignite = Ignition.start(cfg);
        LOGGER.info(
                "Started the server node: Name {}; Id: {}",
                serverName,
                ignite.cluster().node().id()
        );

        System.out.printf("\tNode ID: %s\n\tOS: %s\tJRE: %s\n",
                ignite.cluster().localNode().id(),
                System.getProperty("os.name"),
                System.getProperty("java.runtime.name")
        );

        /*
        * This call effectively gets a handle to the services interface but scoped to only the server nodes in the cluster.
        * By targeting server nodes specifically, you ensure that the services you deploy are only deployed on nodes
        * that are configured to act as servers, which typically have the resources to handle such services.
        * */
        services = ignite.services(ignite.cluster().forServers());

        /*
        * This call deploys a singleton service instance named "MyExecutorService" on each server node in the cluster.
        * A singleton service means that one instance of the service will be deployed per node in the specified
        * cluster group (in this case, all server nodes).
        * */
        services.deployNodeSingleton("MyExecutorService", new SimpleExecutorImpl());

    }

    private void shutdown(){
        ignite.close();
    }
}
