package com.clarifi.phoenix.ashes.common;

import com.amazon.ion.*;
import com.amazon.ion.system.IonSystemBuilder;
import com.amazon.ion.system.IonTextWriterBuilder;

import java.io.OutputStream;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;

public class PackedDataSession implements DataSession {
    private final UUID id;
    private final UUID userId;
    private Status status;
    private int range;
    private int[] issues;
    private int[] dataItems;
    private long lastAccessedAt;

    public PackedDataSession(final UUID id, final UUID userId) {
        this.id = id;
        this.userId = userId;

        status = Status.Initializing;
        range = 0;
        issues = new int[] {};
        dataItems = new int[] {};
    }

    @Override
    public UUID getId() {
        return id;
    }

    @Override
    public UUID getUserId() {
        return userId;
    }

    @Override
    public PhoenixDateRange getRange() {
        return PhoenixDateRange.fromPackedValue(range);
    }

    public void setRange(final PhoenixDateRange range) {
        this.range = range.getPackedValue();
    }

    public void setRange(final int value) {
        this.range = value;
    }

    @Override
    public Status getStatus() {
        return status;
    }

    public void setStatus(final Status value) {
        this.status = value;
    }

    @Override
    public int[] getIssues() {
        return issues;
    }

    public void setIssues(final List<Integer> values) {
        this.issues = asArray(values);
    }

    public void addIssues(final List<Integer> values) {
        this.issues = union(issues, values);
    }

    @Override
    public int[] getDataItems() {
        return dataItems;
    }

    public void setDataItems(final List<Integer> values) {
        this.dataItems = asArray(values);
    }

    public void addDataItems(final List<Integer> values) {
        this.dataItems = union(dataItems, values);
    }

    public void setLastAccessedAt(final long value) {
        this.lastAccessedAt = value;
    }

    @Override
    public Instant getLastAccessedAt() {
        return Instant.ofEpochMilli(lastAccessedAt);
    }

    @Override
    public void updateLastAccessedAt() {
        lastAccessedAt = Instant.now().toEpochMilli();
    }

    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("UUID: ").append(id.toString());
        builder.append(", User: ").append(userId.toString());
        builder.append(", Date range: ").append(getRange());
        builder.append(", Status: ").append(status.toString());

        builder.append(", Data items: [");

        for (int idx = 0; idx < Math.min(8, dataItems.length); idx++) {
            builder.append(Integer.toString(dataItems[idx]));
            if (idx < dataItems.length - 1) {
                builder.append(',');
            }
        }

        if (dataItems.length > 16) {
            builder.append("...]");
        } else {
            builder.append(']');
        }

        builder.append(", Issues: [");

        for (int idx = 0; idx < Math.min(16, issues.length); idx++) {
            builder.append(Integer.toString(issues[idx]));
            if (idx < issues.length - 1) {
                builder.append(',');
            }
        }

        if (issues.length > 16) {
            builder.append("...]");
        } else {
            builder.append(']');
        }

        builder.append(", Last accessed: ").append(getLastAccessedAt());

        return builder.toString();
    }

    private static int[] asArray(final List<Integer> list) {
        // https://stackoverflow.com/questions/960431/how-can-i-convert-listinteger-to-int-in-java

        final int[] temp = new int[list.size()];
        list.forEach(new Consumer<Integer>() {
            int index = 0;
            @Override
            public void accept(final Integer integer) {
                temp[index++] = integer.intValue();
            }
        });

        return temp;
    }

    private static int[] union(final int[] array, final List<Integer> list) {
        final int[] temp = new int[array.length + list.size()];
        System.arraycopy(array, 0, temp, 0, array.length);

        list.forEach(new Consumer<Integer>() {
            int index = array.length;
            @Override
            public void accept(final Integer integer) {
                temp[index++] = integer.intValue();
            }
        });

        return temp;
    }

    public interface Reader {
        DataSession read(byte[] bytes);
    }

    public static class IonReader implements Reader {
        private UUID user = null;
        private PhoenixDateRange range = PhoenixDateRange.empty();
        private final List<Integer> dataItems = new ArrayList<>();
        private final List<Integer> issues = new ArrayList<>();
        private Status status = Status.Initializing;
        private long lastAccessedAt = 0;

        @Override
        public DataSession read(final byte[] bytes) {
            final IonSystem ion = IonSystemBuilder.standard().build();

            UUID uid = UUID.randomUUID();

            try (final com.amazon.ion.IonReader reader = ion.newReader(bytes)) {
                IonType cursor = reader.next();
                reader.stepIn();

                do {
                    cursor = reader.next();
                    if (cursor != null) {
                        switch (reader.getFieldName()) {
                            case "id":
                                uid = UUID.fromString(reader.stringValue());
                                break;

                            case "user":
                                // parseUser(reader);
                                user = UUID.fromString(reader.stringValue());
                                break;

                            case "range":
                                parseRange(reader);
                                break;

                            case "dataItems":
                                parseDataItems(reader);
                                break;

                            case "issues":
                                parseIssues(reader);
                                break;

                            case "statusId":
                                status = Status.fromId(reader.intValue());
                                break;

                            case "statusName":
                                status = Status.fromName(reader.stringValue());
                                break;

                            case "lastAccessedAt":
                                lastAccessedAt = parseLastAccessedAt(reader);
                                break;
                        }
                    }
                } while (cursor != null);

                reader.stepOut();
            } catch (final Throwable err) {
                err.printStackTrace(System.err);
            }

            final PackedDataSession result = new PackedDataSession(uid, user);
            result.setRange(range);
            result.setDataItems(dataItems);
            result.setIssues(issues);
            result.setStatus(status);
            result.setLastAccessedAt(lastAccessedAt);

            return result;
        }

        // todo: extract user API
//        private void parseUser(final IonReader reader) {
//            reader.stepIn();
//
//            UUID id = null;
//            String name = "N/A";
//            String token = null;
//
//            IonType cursor = reader.next();
//            while (cursor != null) {
//                switch (reader.getFieldName()) {
//                    case "id":
//                        id = UUID.fromString(reader.stringValue());
//                        break;
//
//                    case "name":
//                        name = reader.stringValue();
//                        break;
//
//                    case "token":
//                        token = reader.stringValue();
//                        break;
//                }
//
//                cursor = reader.next();
//            }
//
//            reader.stepOut();
//
//            user = new PhoenixUser(id.toString());
//            user.setName(name);
//            user.setOktaToken(token);
//        }

        private void parseRange(final com.amazon.ion.IonReader reader) {
            reader.stepIn();

            PhoenixDate start = PhoenixDate.MIN, end = PhoenixDate.MIN;

            IonType cursor = reader.next();
            while (cursor != null) {
                switch (reader.getFieldName()) {
                    case "start-date":
                        start = parseLocalDate(reader);
                        break;

                    case "end-date":
                        end = parseLocalDate(reader);
                        break;
                }

                cursor = reader.next();
            }

            reader.stepOut();

            range = new PhoenixDateRange(start, end);
        }

        private void parseDataItems(final com.amazon.ion.IonReader reader) {
            reader.stepIn();

            dataItems.clear();

            IonType cursor = reader.next();
            while (cursor != null) {
                dataItems.add(Integer.valueOf(reader.intValue()));
                cursor = reader.next();
            }

            reader.stepOut();
        }

        private void parseIssues(final com.amazon.ion.IonReader reader) {
            reader.stepIn();

            issues.clear();

            IonType cursor = reader.next();
            while (cursor != null) {
                issues.add(Integer.valueOf(reader.intValue()));
                cursor = reader.next();
            }

            reader.stepOut();
        }

        private PhoenixDate parseLocalDate(final com.amazon.ion.IonReader reader) {
            reader.stepIn();

            int year = 0, month = 0, day = 0;

            IonType cursor = reader.next();
            while (cursor != null) {
                switch (reader.getFieldName()) {
                    case "year":
                        year = reader.intValue();
                        break;

                    case "month":
                        month = reader.intValue();
                        break;

                    case "day":
                        day = reader.intValue();
                        break;
                }

                cursor = reader.next();
            }

            reader.stepOut();

            return PhoenixDate.of(year, month, day);
        }

        private long parseLastAccessedAt(final com.amazon.ion.IonReader reader) {
            return reader.longValue();
        }
    }

    public interface Writer {
        void write(OutputStream stream);
        String getMimeType();
    }

    public static class IonWriter implements Writer {
        protected final DataSession session;

        public IonWriter(final DataSession session) {
            this.session = session;
        }

        @Override
        public String getMimeType() {
            return PhoenixMimeTypes.TEXT_ION;
        }

        protected IonStruct buildStruct(final IonSystem ion) {
            final IonStruct params = ion.newEmptyStruct();
            params.add("id", ion.newString(session.getId().toString()));
            params.add("user", ion.newString(session.getUserId().toString()));
            params.add("range", PhoenixDateRange.toIon(session.getRange(), ion));
            params.add("dataItems", ion.newList(session.getDataItems()));
            params.add("issues", ion.newList(session.getIssues()));
            params.add("statusId", ion.newInt(session.getStatus().getId()));
            params.add("statusName", ion.newString(session.getStatus().toString()));
            params.add("lastAccessedAt", ion.newInt(session.getLastAccessedAt().toEpochMilli()));

            return params;
        }

        @Override
        public void write(final OutputStream stream) {
            final IonSystem ion = IonSystemBuilder.standard().build();
            final IonStruct data = buildStruct(ion);

            try (final com.amazon.ion.IonWriter writer = ion.newTextWriter(stream)) {
                data.writeTo(writer);
                writer.flush();
            } catch (final Throwable err) {
                err.printStackTrace(System.err);
            }
        }
    }

    public static class BinaryIonWriter extends IonWriter {
        public BinaryIonWriter(final DataSession session) {
            super(session);
        }

        @Override
        public void write(final OutputStream stream) {
            final IonSystem ion = IonSystemBuilder.standard().build();
            final IonStruct data = buildStruct(ion);

            try (final com.amazon.ion.IonWriter writer = ion.newBinaryWriter(stream)) {
                data.writeTo(writer);
                writer.flush();
            } catch (final Throwable err) {
                err.printStackTrace(System.err);
            }
        }
    }

    public static class JsonWriter extends IonWriter {

        public JsonWriter(final DataSession session) {
            super(session);
        }

        @Override
        public String getMimeType() {
            return PhoenixMimeTypes.TEXT_JSON;
        }

        @Override
        public void write(final OutputStream stream) {
            final IonSystem ion = IonSystemBuilder.standard().build();
            final IonStruct data = buildStruct(ion);

            try (final com.amazon.ion.IonWriter writer = IonTextWriterBuilder.json().build(stream)) {
                data.writeTo(writer);
                writer.flush();
            } catch (final Throwable err) {
                err.printStackTrace(System.err);
            }
        }
    }
}
