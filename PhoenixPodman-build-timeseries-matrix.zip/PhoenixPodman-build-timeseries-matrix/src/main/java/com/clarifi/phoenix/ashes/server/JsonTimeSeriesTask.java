package com.clarifi.phoenix.ashes.server;

import com.amazon.ion.IonList;
import com.amazon.ion.IonSystem;
import com.amazon.ion.IonValue;
import com.amazon.ion.IonWriter;
import com.amazon.ion.system.IonSystemBuilder;
import com.amazon.ion.system.IonTextWriterBuilder;
import com.clarifi.phoenix.ashes.common.DataSession;
import com.clarifi.phoenix.ashes.common.PhoenixDate;
import com.clarifi.phoenix.ashes.data.TimeSeriesMatrix;
import org.apache.ignite.IgniteCompute;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;

public class JsonTimeSeriesTask extends IssueTimeSeriesTask {
    private final List<IonValue> sequence;
    private final IonSystem ion;
    private final IonTextWriterBuilder builder;

    public JsonTimeSeriesTask(final int issueId,
                              final DataSession session,
                              final IgniteCompute compute,
                              final StreamingSenderThread sender) {
        super(issueId, session, compute, sender);

        sequence = new LinkedList<>();

        ion = IonSystemBuilder.standard().build();
        builder = IonTextWriterBuilder.minimal();
        builder.setCharset(StandardCharsets.UTF_8);
    }

    @Override
    protected void renderDataLine(final TimeSeriesMatrix matrix, final LocalDate date,
                                  final ByteArrayOutputStream out) throws IOException {
        sequence.clear();

        sequence.add(ion.newInt(matrix.getIssueId()));
        sequence.add(ion.newString(String.format("%04d-%02d-%02d", date.getYear(), date.getMonthValue(), date.getDayOfMonth())));
        for (final double value: matrix.getValuesFor(PhoenixDate.fromLocalDate(date).getPackedValue())) {
            sequence.add(ion.newDecimal(value));
        }

        final IonWriter writer = builder.withJsonDowngrade().build(out);
        final IonList list = ion.newList(sequence);
        list.writeTo(writer);
        writer.flush();
    }
}
