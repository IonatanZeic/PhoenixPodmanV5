package com.clarifi.phoenix.ashes.common;

import java.util.ArrayList;
import java.util.List;

public class IssueRangeAccumulator {
  public final List<int[]> ranges;
  public int[] currentRange = new int[2];

  public IssueRangeAccumulator() {
    ranges = new ArrayList<>();
    currentRange[0] = -1;
    currentRange[1] = -1;
  }

  public void add(int issueId) {
    if (currentRange[1] == -1) {
      currentRange[0] = issueId;
      currentRange[1] = issueId;

    } else {
      if (issueId == currentRange[1] + 1) {
        currentRange[1] = issueId;
      } else {
        ranges.add(currentRange);
        currentRange = new int[2];
        currentRange[0] = issueId;
        currentRange[1] = issueId;
      }
    }
  }

  @Override
  public String toString() {
    String result = "";
    boolean needComma = false;
    for (int[] range : ranges) {
      if (needComma) {
        result += ", ";
      }
      result += "[" + range[0] + ", " + range[1] + "]";
      needComma = true;
    }
    if (needComma) {
      result += ", ";
    }
    result += "[" + currentRange[0] + ", " + currentRange[1] + "]";
    return result;
  }
}
