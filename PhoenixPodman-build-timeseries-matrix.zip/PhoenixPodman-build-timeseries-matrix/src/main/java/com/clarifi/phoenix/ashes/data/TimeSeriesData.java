package com.clarifi.phoenix.ashes.data;

public class TimeSeriesData {
  public int issueId;
  public int dataItemId;
  public char[] dates;
  public double[] values;

  public TimeSeriesData(int numValues) {
    dates = new char[numValues];
    values = new double[numValues];
  }

  /** copy constructor */
  public TimeSeriesData(TimeSeriesData ts) {
    this.issueId = ts.issueId;
    this.dataItemId = ts.dataItemId;

    int numValues = ts.dates.length;
    this.dates = new char[numValues];
    System.arraycopy(ts.dates, 0, this.dates, 0, numValues);
    this.values = new double[numValues];
    System.arraycopy(ts.values, 0, this.values, 0, numValues);
  }

  public static long sizeInBytes(int numValues) {
    long result = 2 * 4 /*int IDs */ + numValues * 2 /* dates array */ + numValues * 8 /* values array */ + 2 * 8 /* array overhead estimate */;
    return result;
  }

  /**
   *   Create a time series data of specified length with random data
   */
  public static TimeSeriesData fill(int issueId, int dataItemId, int numValues) {
    TimeSeriesData result = new TimeSeriesData(numValues);

    result.issueId = issueId;
    result.dataItemId = dataItemId;

    for (char i = 0; i < numValues; ++i) {
      result.dates[i] = i;
      result.values[i] = issueId + dataItemId + i + Math.random();
    }

    return result;
  }

  @Override
  public String toString() {
    String result = "{issueId: " + issueId + ", numDates: " + dates.length;
    if (dates.length > 0) {
      result += ", value[0] = " + values[0];
    }
    if (dates.length > 1) {
      result += ", value[1] = " + values[1];
    }
    result += " }";

    return result;
  }
}
