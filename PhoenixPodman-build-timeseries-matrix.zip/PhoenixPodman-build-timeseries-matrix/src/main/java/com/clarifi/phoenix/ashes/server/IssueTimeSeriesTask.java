package com.clarifi.phoenix.ashes.server;

import com.clarifi.common.util.Logging;
import com.clarifi.concurrent.Unification;
import com.clarifi.concurrent.batch.task.*;
import com.clarifi.phoenix.ashes.common.*;
import com.clarifi.phoenix.ashes.data.TimeSeriesMatrix;
import com.clarifi.phoenix.ashes.task.BuildTimeSeriesMatrix;
import org.apache.ignite.IgniteCompute;
import org.apache.logging.log4j.Logger;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Callable;

abstract class IssueTimeSeriesTask extends DecompTask<List<Integer>> {
    private static final Logger LOGGER = Logging.getLogger(IssueTimeSeriesTask.class);

    private final int issueId;
    private final DataSession session;
    private final IgniteCompute compute;
    private final StreamingSenderThread sender;

    public IssueTimeSeriesTask(final int issueId, final DataSession session,
                               final IgniteCompute compute, final StreamingSenderThread sender) {
        this.issueId = issueId;
        this.session = session;
        this.compute = compute;
        this.sender = sender;

        setComputeFunction(this::compute);
    }

    public TaskResult<List<Integer>> compute(final DecompTask<List<Integer>> task,
                                             final TaskContext<List<Integer>> context) throws Exception {
        task.prepareScatter(0, this::continuation, Unification.UniteOrFailOnFirstFailure);

        final List<Integer> results = new LinkedList<>();

        final TimeSeriesMatrix matrix = compute.affinityCall(
                TimeSeriesDataCache.getName(),
                Integer.valueOf(issueId),
                new BuildTimeSeriesMatrix(issueId, session.getDataItems(), session.getRange().getPackedValue())
        );

        // todo: aggregate data on the node for a single day
        final PhoenixDateRange range = session.getRange();

        PhoenixDate date = range.getStart();
        while (range.contains(date)) {
            final LocalDate localDate = PhoenixDate.toLocalDate(date);

            task.scatterFor(0, new Callable<List<Integer>>() {
                @Override
                public List<Integer> call() throws Exception {
                    try {
                        final ByteArrayOutputStream temp = new ByteArrayOutputStream();

                        renderDataLine(matrix, localDate, temp);

                        temp.write(",\n".getBytes(StandardCharsets.UTF_8));
                        final byte[] serialized = temp.toByteArray();

                        sender.queueData(serialized);

                        results.add(Integer.valueOf(serialized.length));
                    } catch (final Throwable err) {
                        err.printStackTrace();
                    }

                    return results;
                }
            });

            date = date.plusDays(1);
        }

        task.scatterFullyDefined(0);

        return ContinuationResult.instanceOf();
    }

    private TaskResult<List<Integer>> continuation(final DecompTask<List<Integer>> task,
                                                   final ContinuationContext<List<Integer>> context,
                                                   final TaskResult<?>[] results) {
        final List<Integer> all = new LinkedList<>();

        for (final TaskResult<?> item : results) {
            if (item.isFailure()) {
                LOGGER.error("Failed to get time series data: {}", item);
                continue;
            }

            final SuccessfulResult<List<Integer>> result = (SuccessfulResult<List<Integer>>) item;

            all.addAll(result.result());
        }

        return SuccessfulResult.of(all);
    }

    protected abstract void renderDataLine(
            TimeSeriesMatrix matrix, LocalDate date, ByteArrayOutputStream out) throws IOException;
}
