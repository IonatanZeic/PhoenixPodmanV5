package com.clarifi.phoenix.ashes.common;

import com.clarifi.phoenix.ashes.data.DataItemSlicesIndex;
import com.clarifi.phoenix.ashes.data.TimeSeriesDataKey;
import org.apache.ignite.cache.CacheMode;
import org.apache.ignite.cache.CacheRebalanceMode;
import org.apache.ignite.cache.PartitionLossPolicy;
import org.apache.ignite.cache.affinity.rendezvous.RendezvousAffinityFunction;
import org.apache.ignite.configuration.CacheConfiguration;

public final class TimeSeriesDataCache {
    private static final String NAME = "TIME_SERIES";

    public static String getName() {
        return NAME;
    }

    public static CacheConfiguration<TimeSeriesDataKey, DataItemSlicesIndex> getCacheConfig(final int backups) {
        final CacheConfiguration<TimeSeriesDataKey, DataItemSlicesIndex> config = new CacheConfiguration<>();
        config.setName(NAME);
        config.setCacheMode(CacheMode.PARTITIONED);
        config.setBackups(backups);
        config.setRebalanceMode(CacheRebalanceMode.SYNC);
        config.setPartitionLossPolicy(PartitionLossPolicy.READ_ONLY_SAFE);
        config.setAffinity(new RendezvousAffinityFunction(false, 2048));

        return config;
    }

    public static TimeSeriesDataKey createKey(final int issueId, final int dataItemId) {
        return new TimeSeriesDataKey(issueId, dataItemId);
    }
}
