package com.clarifi.phoenix.ashes.task;

import com.clarifi.phoenix.ashes.common.IssueDataSlicedByDataItem;
import com.clarifi.phoenix.ashes.common.PhoenixDateRange;
import com.clarifi.phoenix.ashes.common.TimeSeriesDataCache;
import com.clarifi.phoenix.ashes.data.DataItemSlicesIndex;
import com.clarifi.phoenix.ashes.data.TimeSeriesDataKey;
import org.apache.ignite.Ignite;
import org.apache.ignite.lang.IgniteCallable;
import org.apache.ignite.resources.IgniteInstanceResource;

import javax.cache.Cache;
import java.util.ArrayList;
import java.util.List;

public class GetTimeSeriesSlices implements IgniteCallable<List<IssueDataSlicedByDataItem>> {
    private final int issueId;
    private final int dataItemId;
    private final PhoenixDateRange range;

    @IgniteInstanceResource
    private Ignite ignite;

    public GetTimeSeriesSlices(int issueId, int dataItemId, final int range) {
        this.issueId = issueId;
        this.dataItemId = dataItemId;
        this.range = PhoenixDateRange.fromPackedValue(range);
    }

    @Override
    public List<IssueDataSlicedByDataItem> call() {
        final TimeSeriesDataKey key = TimeSeriesDataCache.createKey(issueId, dataItemId);

        final Cache<TimeSeriesDataKey, DataItemSlicesIndex> cache = ignite.cache(TimeSeriesDataCache.getName());
        final DataItemSlicesIndex index = cache.get(key);
        if (index == null || index.isEmpty()) {
            return null;
        }

        final List<IssueDataSlicedByDataItem> results = new ArrayList<>();
        for (final IssueDataSlicedByDataItem item : index.getAll()) {
            final PhoenixDateRange itemRange = PhoenixDateRange.fromPackedValue(item.getDateRange());
            if (itemRange.equals(range)) {
                results.add(item);
            } else if (itemRange.includes(range)) {
                results.add(item);
            }
        }

        return results;
    }
}
