package com.phoenix.okta;

import com.phoenix.okta.handlers.HelloHandler;
import com.phoenix.okta.handlers.TokenValidatorMiddleware;
import io.undertow.Handlers;
import io.undertow.Undertow;
import io.undertow.server.HttpHandler;
import io.undertow.server.RoutingHandler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Main {
    private static final Logger _logger = LogManager.getLogger(Main.class);

    public static void main(String[] args){
        HttpHandler helloHandlerWithValidation = new TokenValidatorMiddleware(new HelloHandler());

        RoutingHandler routingHandler = Handlers.routing();
        routingHandler.get("/hello",helloHandlerWithValidation);
        routingHandler.post("/hello",helloHandlerWithValidation);

        Undertow server = Undertow.builder()
                .addHttpListener(8080, "0.0.0.0")
                .setHandler(routingHandler)
                .build();

        server.start();
    }

}
