package com.clarifi.phoenix.apiserver;

import java.nio.ByteBuffer;
import java.util.Deque;
import java.util.Optional;

import com.fasterxml.jackson.core.type.TypeReference;
import io.undertow.server.HttpServerExchange;
import io.undertow.util.Headers;
import io.undertow.util.HttpString;
import io.undertow.util.StatusCodes;

/*
 * Using static globals for simplicity. Use your own DI method however you want.
 */
public class Exchange
{
  private static final BodyImpl BODY = new BodyImpl()
  {
  };

  private static final RedirectImpl REDIRECT = new RedirectImpl()
  {
  };

  private static final QueryParamImpl QUERYPARAMS = new QueryParamImpl()
  {
  };

  private static final PathParamImpl PATHPARAMS = new PathParamImpl()
  {
  };

  private static final HeaderImpl HEADERS = new HeaderImpl()
  {
  };

  public static BodyImpl body()
  {
    return BODY;
  }

  public static RedirectImpl redirect()
  {
    return REDIRECT;
  }

  public static QueryParamImpl queryParams()
  {
    return QUERYPARAMS;
  }

  public static PathParamImpl pathParams()
  {
    return PATHPARAMS;
  }

  public static HeaderImpl headers()
  {
    return HEADERS;
  }

  public interface BodyImpl
  {
    default void sendJson( HttpServerExchange exchange, String json )
    {
      exchange.getResponseHeaders().put( Headers.CONTENT_TYPE, "application/json" );
      exchange.getResponseSender().send( json );
    }

    default void sendJson( HttpServerExchange exchange, byte[] bytes )
    {
      exchange.getResponseHeaders().put( Headers.CONTENT_TYPE, "application/json" );
      exchange.getResponseSender().send( ByteBuffer.wrap( bytes ) );
    }

    default void sendXml( HttpServerExchange exchange, String xml )
    {
      exchange.getResponseHeaders().put( Headers.CONTENT_TYPE, "application/xml" );
      exchange.getResponseSender().send( xml );
    }

    default void sendHtml( HttpServerExchange exchange, String html )
    {
      exchange.getResponseHeaders().put( Headers.CONTENT_TYPE, "text/html" );
      exchange.getResponseSender().send( html );
    }

    default void sendText( HttpServerExchange exchange, String text )
    {
      exchange.getResponseHeaders().put( Headers.CONTENT_TYPE, "text/plain" );
      exchange.getResponseSender().send( text );
    }

    default void sendFile( HttpServerExchange exchange, String fileName, String content )
    {
      exchange.getResponseHeaders().put( Headers.CONTENT_TYPE, "application/octet-stream" );
      exchange.getResponseHeaders().put( Headers.CONTENT_DISPOSITION, "inline; filename=\"" + fileName + "\"" );
      exchange.getResponseSender().send( content );
    }

    default void sendFile( HttpServerExchange exchange, String fileName, byte[] bytes )
    {
      exchange.getResponseHeaders().put( Headers.CONTENT_TYPE, "application/octet-stream" );
      exchange.getResponseHeaders().put( Headers.CONTENT_DISPOSITION, "inline; filename=\"" + fileName + "\"" );
      exchange.getResponseSender().send( ByteBuffer.wrap( bytes ) );
    }

    default void sendJson( HttpServerExchange exchange, Object obj )
    {
      exchange.getResponseHeaders().put( Headers.CONTENT_TYPE, "application/json" );
      exchange.getResponseSender().send( ByteBuffer.wrap( Json.serializer().toByteArray( obj ) ) );
    }

    default <T> T parseJson( HttpServerExchange exchange, TypeReference<T> typeRef )
    {
      return Json.serializer().fromInputStream( exchange.getInputStream(), typeRef );
    }
  }

  public interface RedirectImpl
  {
    default void temporary( HttpServerExchange exchange, String location )
    {
      exchange.setStatusCode( StatusCodes.FOUND );
      exchange.getResponseHeaders().put( Headers.LOCATION, location );
      exchange.endExchange();
    }

    default void permanent( HttpServerExchange exchange, String location )
    {
      exchange.setStatusCode( StatusCodes.MOVED_PERMANENTLY );
      exchange.getResponseHeaders().put( Headers.LOCATION, location );
      exchange.endExchange();
    }

    default void referer( HttpServerExchange exchange )
    {
      exchange.setStatusCode( StatusCodes.FOUND );
      exchange.getResponseHeaders().put( Headers.LOCATION, exchange.getRequestHeaders().get( Headers.REFERER, 0 ) );
      exchange.endExchange();
    }
  }

  public interface QueryParamImpl
  {
    default Optional<String> queryParam( HttpServerExchange exchange, String name )
    {
      return Optional.ofNullable( exchange.getQueryParameters().get( name ) ).map( Deque::getFirst );
    }

    default Optional<Long> queryParamAsLong( HttpServerExchange exchange, String name )
    {
      return queryParam( exchange, name ).map( Long::parseLong );
    }

    default Optional<Integer> queryParamAsInteger( HttpServerExchange exchange, String name )
    {
      return queryParam( exchange, name ).map( Integer::parseInt );
    }

    default Optional<Boolean> queryParamAsBoolean( HttpServerExchange exchange, String name )
    {
      return queryParam( exchange, name ).map( Boolean::parseBoolean );
    }
  }

  public interface PathParamImpl
  {
    default Optional<String> pathParam( HttpServerExchange exchange, String name )
    {
      return Optional.ofNullable( exchange.getPathParameters().get( name ) ).map( Deque::getFirst );
    }

    default Optional<Long> pathParamAsLong( HttpServerExchange exchange, String name )
    {
      return pathParam( exchange, name ).map( Long::parseLong );
    }

    default Optional<Integer> pathParamAsInteger( HttpServerExchange exchange, String name )
    {
      return pathParam( exchange, name ).map( Integer::parseInt );
    }
  }

  public interface HeaderImpl
  {
    default Optional<String> getHeader( HttpServerExchange exchange, HttpString header )
    {
      return Optional.ofNullable( exchange.getRequestHeaders().get( header ) ).map( Deque::getFirst );
    }

    default Optional<String> getHeader( HttpServerExchange exchange, String header )
    {
      return Optional.ofNullable( exchange.getRequestHeaders().get( header ) ).map( Deque::getFirst );
    }

    default void setHeader( HttpServerExchange exchange, HttpString header, String value )
    {
      exchange.getResponseHeaders().add( header, value );
    }

    default void setHeader( HttpServerExchange exchange, String header, String value )
    {
      exchange.getResponseHeaders().add( new HttpString( header ), value );
    }
  }
}
